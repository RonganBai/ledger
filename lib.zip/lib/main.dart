import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'app/app.dart';
import 'data/db/app_database.dart';
import 'features/reports/report_service.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // 1) Supabase first (auth/session need to be ready early).
  await Supabase.initialize(
    url: 'https://bgktgcnivqvkjhurttm.supabase.co',
    // ⚠️ 请确保这里是“完整的” sb_publishable_... key（不要复制到被省略的短串）
    anonKey: 'sb_publishable_Pq1nkxrmB5Ils-eiBImp_A_7PUVBJxv',
  );

  final db = AppDatabase();

  runApp(MyApp(db: db));

  // 2) 非关键启动任务：放到首帧之后，避免启动卡顿（Skipped frames）
  WidgetsBinding.instance.addPostFrameCallback((_) async {
    // 基本连通性日志（不影响功能）
    final client = Supabase.instance.client;
    debugPrint('Supabase inited. url=${client.rest.url}');
    debugPrint('Supabase session=${client.auth.currentSession}');

    // 轻量连通性测试：如果你还没建 accounts 表，这里会打印错误但不会影响运行
    try {
      final res = await client.from('accounts').select('id').limit(1);
      debugPrint('Supabase accounts test: $res');
    } catch (e, st) {
      debugPrint('Supabase accounts test failed: $e');
      debugPrint('$st');
    }

    // 月报归档（可能比较慢）
    try {
      await ReportService.archiveLastMonthIfNeeded(db);
      debugPrint('ReportService.archiveLastMonthIfNeeded done');
    } catch (e, st) {
      debugPrint('ReportService.archiveLastMonthIfNeeded failed: $e');
      debugPrint('$st');
    }
  });
}
