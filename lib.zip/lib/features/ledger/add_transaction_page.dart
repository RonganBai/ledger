import 'package:flutter/material.dart';
import 'package:drift/drift.dart' as d;

import '../../data/db/app_database.dart';
import '../../l10n/category_i18n.dart';
import '../../l10n/tr.dart';

import '../../ui/pet/pet_bus.dart';
import '../../ui/pet/pet_talker.dart';

class AddTransactionPage extends StatefulWidget {
  final AppDatabase db;

  /// When provided, page works in "edit" mode and updates this transaction.
  final Transaction? initialTx;

  const AddTransactionPage({
    super.key,
    required this.db,
    this.initialTx,
  });

  @override
  State<AddTransactionPage> createState() => _AddTransactionPageState();
}

class _AddTransactionPageState extends State<AddTransactionPage> {
  final _amountController = TextEditingController();
  final _contentController = TextEditingController();

  bool _isIncome = false;
  int? _categoryId;
  bool _catExpanded = false;
  bool _catManageMode = false;
  final _newCatController = TextEditingController();
  late DateTime _occurredAt;

  AppDatabase get db => widget.db;

  bool get _isEdit => widget.initialTx != null;

  @override
  void initState() {
    super.initState();

    final tx = widget.initialTx;
    if (tx != null) {
      _isIncome = tx.direction == 'income';
      _categoryId = tx.categoryId;
      _occurredAt = tx.occurredAt;

      _amountController.text = (tx.amountCents / 100.0).toStringAsFixed(2);

      if (tx.merchant != null) _contentController.text = tx.merchant!;    } else {
      _occurredAt = DateTime.now();
    }
  }

  Future<String?> _categoryNameById(int? id) async {
    if (id == null) return null;
    final row = await (db.select(db.categories)..where((c) => c.id.equals(id)))
        .getSingleOrNull();
    return row?.name;
  }

  Future<List<Category>> _loadCategories() {
    final q = db.select(db.categories)
      ..where((c) => c.direction.equals(_isIncome ? 'income' : 'expense'))
      ..where((c) => c.isActive.equals(true))
      ..orderBy([(c) => d.OrderingTerm(expression: c.sortOrder)]);
    return q.get();
  }

  Future<void> _pickDateOnly() async {
    final now = DateTime.now();
    final initial = _occurredAt;

    final date = await showDatePicker(
      context: context,
      initialDate: DateTime(initial.year, initial.month, initial.day),
      firstDate: DateTime(now.year - 5),
      lastDate: DateTime(now.year + 5),
    );
    if (date == null || !mounted) return;

    setState(() {
      // 只保存日期，不需要精确时间
      _occurredAt = DateTime(date.year, date.month, date.day);
    });
  }

String _fmtDate(DateTime dt) {
    String two(int v) => v.toString().padLeft(2, '0');
    return '${dt.year}-${two(dt.month)}-${two(dt.day)}';
  }


  


  Future<void> _save() async {
    final amount = double.tryParse(_amountController.text.trim());
    if (amount == null) return;

    final content = _contentController.text.trim();
    final isIncome = _isIncome;
    final cents = (amount * 100).round();

    if (_isEdit) {
      final tx = widget.initialTx!;
      await (db.update(db.transactions)..where((t) => t.id.equals(tx.id))).write(
        TransactionsCompanion(
          direction: d.Value(isIncome ? 'income' : 'expense'),
          amountCents: d.Value(cents),
          occurredAt: d.Value(_occurredAt),
          categoryId: d.Value(_categoryId),
          merchant: d.Value(content.isEmpty ? null : content),        ),
      );
    } else {
      final id = DateTime.now().millisecondsSinceEpoch.toString();
      await db.into(db.transactions).insert(
            TransactionsCompanion.insert(
              id: id,
              accountId: 1,
              direction: d.Value(isIncome ? 'income' : 'expense'),
              amountCents: cents,
              occurredAt: _occurredAt,
              categoryId: d.Value(_categoryId),
              merchant: d.Value(content.isEmpty ? null : content),            ),
          );
    }
        // ✅ 写入成功后：触发宠物自动发言
    final pet = PetBus.controller;
    if (pet != null && !_isEdit) {
      final talker = PetTalker(pet);

      final catName = await _categoryNameById(_categoryId);
      final locale = Localizations.localeOf(context);

      talker.onTransactionAdded(
        kind: isIncome ? TxKind.income : TxKind.expense,
        amountCents: cents,
        categoryName: catName,
        locale: locale,
      );
    }

    if (!mounted) return;
    Navigator.pop(context, true);
  }

  @override
  void dispose() {
    _amountController.dispose();
    _contentController.dispose();    super.dispose();
  }

  
  Future<int> _nextSortOrder(String direction) async {
    final q = db.selectOnly(db.categories)
      ..addColumns([db.categories.sortOrder.max()])
      ..where(db.categories.direction.equals(direction));

    final row = await q.getSingle();
    final maxVal = row.read(db.categories.sortOrder.max()) ?? 0;
    return maxVal + 1;
  }

  Future<void> _addCategory(String name) async {
    final trimmed = name.trim();
    if (trimmed.isEmpty) return;

    final direction = _isIncome ? 'income' : 'expense';
    final next = await _nextSortOrder(direction);

    try {
      // 1) 先查是否已存在（哪怕 isActive=false）
      final existing = await (db.select(db.categories)
            ..where((c) => c.name.equals(trimmed) & c.direction.equals(direction)))
          .getSingleOrNull();

      int id;

      if (existing != null) {
        // 2) 存在则“复活” + 更新排序
        await (db.update(db.categories)..where((c) => c.id.equals(existing.id))).write(
          CategoriesCompanion(
            isActive: const d.Value(true),
            sortOrder: d.Value(next),
          ),
        );
        id = existing.id;
      } else {
        // 3) 不存在才插入
        final inserted = await db.into(db.categories).insertReturning(
              CategoriesCompanion(
                name: d.Value(trimmed),
                direction: d.Value(direction),
                isActive: const d.Value(true),
                sortOrder: d.Value(next),
              ),
            );
        id = inserted.id;
      }

      // 4) 选中新分类并刷新
      if (!mounted) return;
      setState(() {
        _categoryId = id;
        _catExpanded = true; // 你要不要自动展开随你，这里先让它保持展开
      });
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            tr(context, en: 'Failed to add category: $e', zh: '新增类别失败：$e'),
          ),
        ),
      );
    }
  }

  Future<void> _deleteCategory(int id) async {
    // ✅ 真删除：把该分类下的账单迁移到 other，然后删除分类本身（释放 UNIQUE(name, direction)）
    await db.deleteCategoryAndMoveToOther(id);
    if (_categoryId == id) _categoryId = null;
  }


  void _toggleCategoryExpanded() {
    setState(() {
      _catExpanded = !_catExpanded;
      if (!_catExpanded) _catManageMode = false;
    });
  }

String _categoryDisplayName(BuildContext context, String raw) {
    final translated = categoryLabel(context, raw);
    if (translated != raw) return translated;

    final lang = Localizations.localeOf(context).languageCode.toLowerCase();
    final isZh = lang.startsWith('zh');
    if (!isZh) return raw;

    const zhFallback = <String, String>{
      // Expense
      'Food': '餐饮',
      'Dining': '餐饮',
      'Groceries': '杂货',
      'Shopping': '购物',
      'Transport': '交通',
      'Transportation': '交通',
      'Gas': '加油',
      'Fuel': '加油',
      'Rent': '房租',
      'Utilities': '水电煤',
      'Electricity': '电费',
      'Water': '水费',
      'Internet': '网络',
      'Phone': '电话费',
      'Entertainment': '娱乐',
      'Healthcare': '医疗',
      'Medical': '医疗',
      'Pharmacy': '药品',
      'Insurance': '保险',
      'Travel': '旅行',
      'Education': '教育',
      'Pets': '宠物',
      'Gift': '礼物',
      'Gifts': '礼物',
      'Other': '其他',

      // Income
      'Salary': '工资',
      'Wages': '工资',
      'Bonus': '奖金',
      'Interest': '利息',
      'Investment': '投资',
      'Investments': '投资',
      'Refund': '退款',
      'Reimbursement': '报销',
      'Transfer': '转账',
    };

    final key = raw.trim();
    return zhFallback[key] ?? raw;
  }

  @override
  Widget build(BuildContext context) {
    final typeLabel = _isIncome ? tr(context, en: 'Income', zh: '收入') : tr(context, en: 'Expense', zh: '支出');
    final title = _isEdit ? tr(context, en: 'Edit', zh: '编辑') : tr(context, en: 'Add', zh: '添加');

    final scheme = Theme.of(context).colorScheme;
    final fieldTextStyle = const TextStyle(fontSize: 16, fontWeight: FontWeight.w700);
    final hintStyle = TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: Colors.black.withValues(alpha: 0.45));

    InputDecoration semiDec({required String label, Widget? suffix}) {
      final base = InputDecoration(
        labelText: label,
        filled: true,
        fillColor: scheme.surfaceContainerHighest,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide.none,
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: Colors.black.withValues(alpha: 0.08)),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: _isIncome ? Colors.green : Colors.red, width: 2),
        ),
      );
      if (suffix == null) return base;
      return base.copyWith(suffixIcon: suffix);
    }

    return Scaffold(
      appBar: AppBar(title: Text('$title $typeLabel')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // Time / date
          InkWell(
            onTap: _pickDateOnly,
            borderRadius: BorderRadius.circular(12),
            child: InputDecorator(
              decoration: semiDec(
                label: tr(context, en: 'Date', zh: '日期'),
                suffix: const Icon(Icons.edit_calendar_rounded),
              ),
              child: Text(_fmtDate(_occurredAt), style: fieldTextStyle),
            ),
          ),

const SizedBox(height: 12),

          SegmentedButton<bool>(
            style: ButtonStyle(
              backgroundColor: WidgetStateProperty.resolveWith<Color?>((states) {
                if (!states.contains(WidgetState.selected)) return null;
                return _isIncome
                    ? Colors.green.withValues(alpha: 0.18)
                    : Colors.red.withValues(alpha: 0.18);
              }),
              foregroundColor: WidgetStateProperty.resolveWith<Color?>((states) {
                if (!states.contains(WidgetState.selected)) return null;
                return _isIncome ? Colors.green : Colors.red;
              }),
              side: WidgetStateProperty.resolveWith<BorderSide?>((states) {
                if (!states.contains(WidgetState.selected)) {
                  return const BorderSide(color: Colors.grey);
                }
                return BorderSide(
                  color: _isIncome ? Colors.green : Colors.red,
                  width: 1.5,
                );
              }),
            ),
            segments: [
              ButtonSegment(
                value: false,
                label: Text(tr(context, en: 'Expense', zh: '支出')),
                icon: const Icon(Icons.remove_circle_outline),
              ),
              ButtonSegment(
                value: true,
                label: Text(tr(context, en: 'Income', zh: '收入')),
                icon: const Icon(Icons.add_circle_outline),
              ),
            ],
            selected: {_isIncome},
            onSelectionChanged: (s) => setState(() {
              _isIncome = s.first;
              _categoryId = null;
            }),
          ),
          const SizedBox(height: 16),

          const SizedBox(height: 12),
          TextField(
            controller: _amountController,
            style: fieldTextStyle,
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            decoration: semiDec(label: tr(context, en: 'Amount', zh: '金额')),
          ),
          const SizedBox(height: 12),
          FutureBuilder<List<Category>>(
            future: _loadCategories(),
            builder: (context, snapshot) {
              final cats = snapshot.data ?? const <Category>[];

              Category? selected;
              for (final c in cats) {
                if (c.id == _categoryId) {
                  selected = c;
                  break;
                }
              }

              final selectedText = selected == null ? '' : _categoryDisplayName(context, selected.name);

              return Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  InkWell(
                    onTap: _toggleCategoryExpanded,
                    borderRadius: BorderRadius.circular(12),
                    child: InputDecorator(
                      decoration: semiDec(
                        label: tr(context, en: 'Category', zh: '类型'),
                        suffix: Icon(
                          _catExpanded ? Icons.expand_less_rounded : Icons.expand_more_rounded,
                        ),
                      ),
                      child: Text(
                        selectedText.isEmpty ? tr(context, en: 'Select', zh: '请选择') : selectedText,
                        style: selectedText.isEmpty ? hintStyle : fieldTextStyle,
                      ),
                    ),
                  ),
                  AnimatedSize(
                    duration: const Duration(milliseconds: 180),
                    curve: Curves.easeOut,
                    child: !_catExpanded
                        ? const SizedBox.shrink()
                        : Padding(
                            padding: const EdgeInsets.only(top: 10),
                            child: Container(
                              padding: const EdgeInsets.all(12),
                              decoration: BoxDecoration(
                                color: scheme.surfaceContainerHighest,
                                borderRadius: BorderRadius.circular(12),
                                border: Border.all(color: Colors.black.withValues(alpha: 0.08)),
                              ),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    children: [
                                      Expanded(
                                        child: Text(
                                          tr(context, en: 'Categories', zh: '类别'),
                                          style: const TextStyle(fontWeight: FontWeight.w800),
                                        ),
                                      ),
                                      TextButton(
                                        onPressed: () => setState(() => _catManageMode = !_catManageMode),
                                        child: Text(
                                          _catManageMode
                                              ? tr(context, en: 'Done', zh: '完成')
                                              : tr(context, en: 'Edit', zh: '编辑'),
                                          style: const TextStyle(fontWeight: FontWeight.w800),
                                        ),
                                      ),
                                    ],
                                  ),
                                  const SizedBox(height: 8),

                                  if (_catManageMode) ...[
                                    Row(
                                      children: [
                                        Expanded(
                                          child: TextField(
                                            controller: _newCatController,
                                            style: fieldTextStyle,
                                            decoration: semiDec(
                                              label: tr(context, en: 'New category', zh: '新增类别'),
                                            ),
                                          ),
                                        ),
                                        const SizedBox(width: 10),
                                        FilledButton(
                                          onPressed: () async {
                                            final name = _newCatController.text;
                                            _newCatController.clear();
                                            await _addCategory(name);
                                            setState(() {});
                                          },
                                          child: Text(tr(context, en: 'Add', zh: '添加')),
                                        ),
                                      ],
                                    ),
                                    const SizedBox(height: 10),
                                    ConstrainedBox(
                                      constraints: const BoxConstraints(maxHeight: 240),
                                      child: ListView.separated(
                                        shrinkWrap: true,
                                        itemCount: cats.length,
                                        separatorBuilder: (_, __) => Divider(
                                          height: 1,
                                          color: Colors.black.withValues(alpha: 0.08),
                                        ),
                                        itemBuilder: (ctx, i) {
                                          final c = cats[i];
                                          final name = _categoryDisplayName(context, c.name);
                                          return ListTile(
                                            dense: true,
                                            contentPadding: EdgeInsets.zero,
                                            title: Text(
                                              name,
                                              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800),
                                            ),
                                            trailing: IconButton(
                                              icon: const Icon(Icons.delete_outline),
                                              onPressed: () async {
                                                await _deleteCategory(c.id);
                                                setState(() {});
                                              },
                                            ),
                                            onTap: () {
                                              setState(() {
                                                _categoryId = c.id;
                                                _catExpanded = false;
                                                _catManageMode = false;
                                              });
                                            },
                                          );
                                        },
                                      ),
                                    ),
                                  ] else ...[
                                    Wrap(
                                      spacing: 10,
                                      runSpacing: 10,
                                      children: [
                                        for (final c in cats)
                                          ChoiceChip(
                                            showCheckmark: false,
                                            label: Text(
                                              _categoryDisplayName(context, c.name),
                                              style: TextStyle(
                                                fontSize: 15,
                                                fontWeight: FontWeight.w800,
                                                color: (_categoryId == c.id)
                                                    ? (_isIncome ? Colors.green : Colors.red) // ✅ 选中颜色
                                                    : Colors.black87,                         // ✅ 未选中颜色（你也可以改成 Colors.grey）
                                              ),
                                            ),
                                            selected: _categoryId == c.id,
                                            selectedColor: (_isIncome ? Colors.green : Colors.red).withValues(alpha: 0.18),
                                            backgroundColor: scheme.surface,
                                            side: BorderSide(color: Colors.black.withValues(alpha: 0.10)),
                                            onSelected: (_) {
                                              setState(() {
                                                _categoryId = c.id;
                                                _catExpanded = false;
                                              });
                                            },
                                          ),
                                      ],
                                    ),
                                  ],
                                ],
                              ),
                            ),
                          ),
                  ),
                ],
              );            },
          ),

const SizedBox(height: 12),
          TextField(
            controller: _contentController,
            style: fieldTextStyle,
            decoration: semiDec(label: tr(context, en: 'Content', zh: '消费内容')),
          ),
          const SizedBox(height: 20),
          FilledButton(
            style: FilledButton.styleFrom(
              backgroundColor: _isIncome ? Colors.green : Colors.red,
              foregroundColor: Colors.white,
              minimumSize: const Size.fromHeight(48),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
            ),
            onPressed: _save,
            child: Text(_isEdit ? tr(context, en: 'Save', zh: '保存') : tr(context, en: 'Add', zh: '添加')),
          ),
        ],
      ),
    );
  }
}