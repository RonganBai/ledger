import 'package:flutter/material.dart';

import '../../../l10n/tr.dart';

class LedgerSideMenu extends StatelessWidget {
  final WidgetBuilder statsPageBuilder;
  final VoidCallback? onOpenStats;
  final VoidCallback onOpenHistory;
  final VoidCallback onOpenCategories;
  final VoidCallback onOpenSettings;

  const LedgerSideMenu({
    super.key,
    required this.statsPageBuilder,
    this.onOpenStats,
    required this.onOpenHistory,
    required this.onOpenCategories,
    required this.onOpenSettings,
  });

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;

    Widget groupTitle(String text) => Padding(
          padding: const EdgeInsets.fromLTRB(18, 16, 18, 10),
          child: Text(
            text,
            style: Theme.of(context).textTheme.labelLarge?.copyWith(
                  color: cs.onSurfaceVariant,
                  fontWeight: FontWeight.w700,
                ),
          ),
        );

    Widget tile({
      required IconData icon,
      required String title,
      required VoidCallback onTap,
    }) {
      return InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          child: Row(
            children: [
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  color: cs.surfaceContainerHighest,
                  borderRadius: BorderRadius.circular(14),
                ),
                alignment: Alignment.center,
                child: Icon(icon, size: 22, color: cs.onSurface),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  title,
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                        fontWeight: FontWeight.w700,
                      ),
                ),
              ),
              Icon(Icons.chevron_right_rounded, color: cs.onSurfaceVariant),
            ],
          ),
        ),
      );
    }

    Widget card({required List<Widget> children}) {
      return Padding(
        padding: const EdgeInsets.symmetric(horizontal: 14),
        child: Material(
          color: cs.surface,
          elevation: 0,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(18),
            side: BorderSide(color: cs.outlineVariant),
          ),
          child: Column(
            children: [
              for (int i = 0; i < children.length; i++) ...[
                children[i],
                if (i != children.length - 1)
                  Divider(height: 1, thickness: 1, color: cs.outlineVariant.withOpacity(0.5)),
              ],
            ],
          ),
        ),
      );
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        // No title bar: looks like a sheet covering the left side.
        const SizedBox(height: 8),

        groupTitle(tr(context, en: 'Navigate', zh: '导航')),
        card(
          children: [
            tile(
              icon: Icons.analytics_rounded,
              title: tr(context, en: 'Stats', zh: '统计'),
              onTap: () {
                // Prefer in-place open (home<->stats paged), if provided by parent.
                if (onOpenStats != null) {
                  onOpenStats!.call();
                  return;
                }
                // Fallback: close the menu and push a normal page.
                Navigator.of(context).maybePop();
                Navigator.of(context).push(
                  MaterialPageRoute(builder: statsPageBuilder),
                );
              },
            ),
            tile(
              icon: Icons.calendar_month_rounded,
              title: tr(context, en: 'History', zh: '历史'),
              onTap: onOpenHistory,
            ),
            tile(
              icon: Icons.category_outlined,
              title: tr(context, en: 'Categories', zh: '类别管理'),
              onTap: onOpenCategories,
            ),
          ],
        ),

        groupTitle(tr(context, en: 'Preferences', zh: '偏好')),
        card(
          children: [
            tile(
              icon: Icons.settings_rounded,
              title: tr(context, en: 'Settings', zh: '设置'),
              onTap: onOpenSettings,
            ),
          ],
        ),

        const Spacer(),
        Padding(
          padding: const EdgeInsets.fromLTRB(14, 0, 14, 14),
          child: Text(
            tr(context, en: 'Swipe left to close', zh: '左滑关闭菜单'),
            textAlign: TextAlign.center,
            style: Theme.of(context).textTheme.labelMedium?.copyWith(
                  color: cs.onSurfaceVariant,
                ),
          ),
        ),
      ],
    );
  }
}
