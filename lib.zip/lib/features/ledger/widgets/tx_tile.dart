import 'package:flutter/material.dart';
import '../../../l10n/tr.dart';

class TxTile extends StatelessWidget {
  final String id;
  final String time;
  final String title;
  final String? subtitle;
  final double amount;
  final bool isIncome;
  final VoidCallback onDelete;
  final VoidCallback onEdit;

  const TxTile({
    super.key,
    required this.id,
    required this.time,
    required this.title,
    required this.subtitle,
    required this.amount,
    required this.isIncome,
    required this.onDelete,
    required this.onEdit,
  });

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final moneyColor = isIncome ? scheme.tertiary : scheme.error;

    return Dismissible(
      key: ValueKey(id),
      direction: DismissDirection.horizontal,

      // Swipe right (start->end): Edit
      background: Container(
        margin: const EdgeInsets.symmetric(horizontal: 0, vertical: 0),
        decoration: BoxDecoration(
          color: scheme.primary,
          borderRadius: BorderRadius.circular(16),
        ),
        alignment: Alignment.centerLeft,
        padding: const EdgeInsets.symmetric(horizontal: 18),
        child: const Icon(Icons.edit_rounded, color: Colors.white),
      ),

      // Swipe left (end->start): Delete
      secondaryBackground: Container(
        margin: const EdgeInsets.symmetric(horizontal: 0, vertical: 0),
        decoration: BoxDecoration(
          color: scheme.error,
          borderRadius: BorderRadius.circular(16),
        ),
        alignment: Alignment.centerRight,
        padding: const EdgeInsets.symmetric(horizontal: 18),
        child: const Icon(Icons.delete_rounded, color: Colors.white),
      ),

      confirmDismiss: (direction) async {
        if (direction == DismissDirection.startToEnd) {
          // Enter edit mode, but do NOT dismiss the tile.
          onEdit();
          return false;
        }

        // Delete confirmation
        return (await showDialog<bool>(
              context: context,
              builder: (_) => AlertDialog(
                title: Text(tr(context, en: 'Delete transaction?', zh: '确认删除？')),
                content: Text(
                  tr(
                    context,
                    en: 'Delete ${isIncome ? '+' : '-'}\$${amount.toStringAsFixed(2)} ?',
                    zh: '删除 ${isIncome ? '+' : '-'}\$${amount.toStringAsFixed(2)} 吗？',
                  ),
                ),
                actionsPadding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
                actionsAlignment: MainAxisAlignment.end,
                actionsOverflowAlignment: OverflowBarAlignment.end,

                actions: [
                  OutlinedButton(
                    style: OutlinedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      side: BorderSide(color: Theme.of(context).colorScheme.outline),
                      backgroundColor: Theme.of(context).colorScheme.surfaceVariant,
                    ),
                    onPressed: () => Navigator.pop(context, false),
                    child: Text(tr(context, en: 'Cancel', zh: '取消')),
                  ),
                  FilledButton(
                    style: FilledButton.styleFrom(
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      backgroundColor: Theme.of(context).colorScheme.error,
                      foregroundColor: Theme.of(context).colorScheme.onError,
                    ),
                    onPressed: () => Navigator.pop(context, true),
                    child: Text(tr(context, en: 'Delete', zh: '删除')),
                  ),
                ],
              ),
            )) ??
            false;
      },

      onDismissed: (direction) {
        if (direction == DismissDirection.endToStart) {
          onDelete();
        }
      },

      child: Card(
        margin: const EdgeInsets.symmetric(horizontal: 0, vertical: 3),
        child: ListTile(
          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 0),
          leading: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(time, style: const TextStyle(fontWeight: FontWeight.w800)),
              const SizedBox(height: 4),
              Container(
                width: 10,
                height: 10,
                decoration: BoxDecoration(
                  color: moneyColor,
                  shape: BoxShape.circle,
                ),
              ),
            ],
          ),
          title: Text(title, maxLines: 1, overflow: TextOverflow.ellipsis),
          subtitle: subtitle == null ? null : Text(subtitle!, maxLines: 1, overflow: TextOverflow.ellipsis),
          trailing: Text(
            '${isIncome ? '+' : '-'}\$${amount.toStringAsFixed(2)}',
            style: TextStyle(
              fontSize: 17,            // 🔥 原来没写 → 加大
              fontWeight: FontWeight.w800,
              letterSpacing: 0.3,      // 🔥 微调更有质感
              color: moneyColor,
            ),
          ),
        ),
      ),
    );
  }
}
