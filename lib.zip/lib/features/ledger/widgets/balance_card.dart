import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../../../l10n/tr.dart';

class BalanceCard extends StatelessWidget {
  final double balance;

  /// The accent color used for border/gradient (e.g., green normally, red when low balance).
  final Color? accentColor;
  final bool isLow; // ✅ 新增
  const BalanceCard({
    super.key,
    required this.balance,
    required this.isLow,
    this.accentColor,
  });

  @override
  Widget build(BuildContext context) {
    // 自适应：以 390（iPhone 12/13）为基准缩放
    final w = MediaQuery.sizeOf(context).width;
    final scale = (w / 390.0).clamp(0.85, 1.15);

    final mainColor = accentColor ?? Colors.green;

    // 字体/间距随屏幕缩放
    final titleSize = 14.0 * scale;
    final valueSize = 34.0 * scale;
    final padV = 22.0 * scale;
    final padH = 18.0 * scale;
    final radius = 20.0 * scale;

    return Container(
      constraints: const BoxConstraints(maxWidth: 560), // 大屏别拉太宽
      decoration: BoxDecoration(
        // 背景改为浅色系，方便黑字
        gradient: LinearGradient(
          colors: [
            mainColor.withOpacity(0.14),
            mainColor.withOpacity(0.06),
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(radius),
        border: Border.all(color: mainColor.withOpacity(0.35)),
      ),
      padding: EdgeInsets.symmetric(vertical: padV, horizontal: padH),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Text(
            tr(context, en: 'BALANCE', zh: '当前余额'),
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: titleSize,
              fontWeight: FontWeight.w900,
              letterSpacing: 1.2,
              color: Colors.black87, // ✅ 黑色标题
            ),
          ),
          SizedBox(height: 10 * scale),
          FittedBox(
            fit: BoxFit.scaleDown,
            // FittedBox：数字再大也不会溢出
            child: Text(
              '\$${balance.toStringAsFixed(2)}',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: valueSize,
                fontWeight: FontWeight.w900,
                color: Colors.black, // ✅ 黑色余额数字
              ),
            ),
          ),
          SizedBox(height: 6 * scale),
          Text(
            isLow
                ? tr(context, en: 'Negative', zh: '余额告急')
                : tr(context, en: 'Healthy', zh: '余额充足'),
            style: TextStyle(
              fontSize: 12 * scale,
              fontWeight: FontWeight.w700,
              color: Colors.black54,
            ),
          ),
        ],
      ),
    );
  }
}
