import 'package:flutter/material.dart';

class LedgerQuickActions extends StatelessWidget {
  final bool isSearchOpen;

  final VoidCallback onToggleSearch;
  final VoidCallback onOpenAdd;

  /// 可自定义按键 3 & 4
  final IconData slot3Icon;
  final String slot3Tooltip;
  final VoidCallback onSlot3;

  final IconData slot4Icon;
  final String slot4Tooltip;
  final VoidCallback onSlot4;

  const LedgerQuickActions({
    super.key,
    required this.isSearchOpen,
    required this.onToggleSearch,
    required this.onOpenAdd,
    required this.slot3Icon,
    required this.slot3Tooltip,
    required this.onSlot3,
    required this.slot4Icon,
    required this.slot4Tooltip,
    required this.onSlot4,
  });

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;

    const double size = 65;   // 按钮尺寸
    const double gapY = 10;   // 行间距
    const double rightPad = 0; // 整组离右边距离（想留空就改成 8/12）

    Widget btn({
      required IconData icon,
      required String tooltip,
      required VoidCallback onTap,
      bool selected = false,
    }) {
      final bg = selected ? scheme.primaryContainer : scheme.surface;
      final fg = selected ? scheme.onPrimaryContainer : scheme.onSurface;
      final border = Theme.of(context).dividerColor.withValues(alpha: 90);

      return Material(
        color: bg,
        borderRadius: BorderRadius.circular(14),
        child: InkWell(
          borderRadius: BorderRadius.circular(14),
          onTap: onTap,
          child: Container(
            width: size,
            height: size,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: border),
            ),
            child: Tooltip(
              message: tooltip,
              child: Icon(icon, color: fg, size: 35),
            ),
          ),
        ),
      );
    }

    return LayoutBuilder(
      builder: (context, c) {
        // 动态计算 gapX
        // leftPad == gapX
        final raw = (c.maxWidth - rightPad - size * 2) / 2;

        // 最大不超过 28，避免屏幕太宽拉得太散
        final gapX = raw.clamp(0.0, 28.0);
        final leftPad = gapX;

        return Align(
          alignment: Alignment.centerRight, // 永远靠右
          child: Padding(
            padding: EdgeInsets.only(left: leftPad, right: rightPad),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                /// 第一行
                Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    btn(
                      icon: Icons.search_rounded,
                      tooltip: 'Search',
                      onTap: onToggleSearch,
                      selected: isSearchOpen,
                    ),
                    SizedBox(width: gapX),
                    btn(
                      icon: Icons.add_rounded,
                      tooltip: 'Add',
                      onTap: onOpenAdd,
                    ),
                  ],
                ),

                SizedBox(height: gapY),

                /// 第二行
                Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    btn(
                      icon: slot3Icon,
                      tooltip: slot3Tooltip,
                      onTap: onSlot3,
                    ),
                    SizedBox(width: gapX),
                    btn(
                      icon: slot4Icon,
                      tooltip: slot4Tooltip,
                      onTap: onSlot4,
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}