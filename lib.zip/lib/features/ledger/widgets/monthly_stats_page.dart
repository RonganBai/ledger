import 'package:flutter/material.dart';

import '../../../data/db/app_database.dart';
import '../../../l10n/tr.dart';

import '../../reports/report_service.dart';
import '../../reports/widgets/monthly_stats_sheet.dart';

class MonthlyStatsPage extends StatelessWidget {
  final AppDatabase db;
  const MonthlyStatsPage({super.key, required this.db});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(tr(context, en: 'Stats', zh: '统计')),
      ),
      body: SafeArea(
        child: MonthlyStatsSheet(service: ReportService(db)),
      ),
    );
  }
}
