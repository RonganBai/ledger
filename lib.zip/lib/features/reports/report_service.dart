import 'dart:convert';
import 'dart:io';

import 'package:drift/drift.dart' as d;
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../data/db/app_database.dart';
import 'models.dart';
import 'widgets/balance_trend_line.dart';

class ReportService {
  final AppDatabase db;

  ReportService(this.db);

  // ====== existing archive storage (keep as static so old code can still call it) ======
  static const _kLastArchivedMonth = 'last_archived_month'; // yyyy-MM

  static String monthKey(DateTime dt) {
    String two(int n) => n.toString().padLeft(2, '0');
    return '${dt.year}-${two(dt.month)}';
  }

  static DateTime monthStart(DateTime dt) => DateTime(dt.year, dt.month, 1);
  static DateTime nextMonthStart(DateTime dt) =>
      (dt.month == 12) ? DateTime(dt.year + 1, 1, 1) : DateTime(dt.year, dt.month + 1, 1);

  static DateTime dayStart(DateTime dt) => DateTime(dt.year, dt.month, dt.day);

  /// 周起始（默认周一），返回当天 00:00
  static DateTime weekStart(DateTime dt, {int weekStartDay = DateTime.monday}) {
    final d0 = dayStart(dt);
    final diff = (d0.weekday - weekStartDay) % 7;
    return d0.subtract(Duration(days: diff));
  }

  /// 生成“任意时间范围”的统计报告（start 包含，end 不包含）
  static Future<MonthlyReport> buildForRange(
    AppDatabase db,
    DateTime start,
    DateTime end, {
    required String label,
  }) async {
    final query = db.select(db.transactions)
      ..where((t) => t.occurredAt.isBetweenValues(start, end))
      ..orderBy([(t) => d.OrderingTerm(expression: t.occurredAt)]);

    final rows = await query.get();

    int income = 0;
    int expense = 0;
    final byCat = <String, int>{};
    final txs = <MonthlyTx>[];

    final catAll = await db.select(db.categories).get();
    final catNameById = {for (final c in catAll) c.id: c.name};

    for (final tx in rows) {
      final cents = tx.amountCents;
      final name = catNameById[tx.categoryId] ?? 'Uncategorized';

      if (tx.direction == 'income') {
        income += cents;
      } else {
        expense += cents;
        byCat[name] = (byCat[name] ?? 0) + cents;
      }

      txs.add(
        MonthlyTx(
          id: tx.id,
          direction: tx.direction,
          amountCents: cents,
          occurredAt: tx.occurredAt,
          categoryName: name,
          merchant: tx.merchant,
          memo: tx.memo,
        ),
      );
    }

    return MonthlyReport(
      monthKey: label,
      incomeCents: income,
      expenseCents: expense,
      expenseByCategoryCents: byCat,
      transactions: txs,
      createdAtEpochMs: DateTime.now().millisecondsSinceEpoch,
    );
  }

  static Future<MonthlyReport> buildForLastDays(AppDatabase db, int days, {DateTime? now}) async {
    final n = now ?? DateTime.now();
    final end = dayStart(n).add(const Duration(days: 1)); // 明天 00:00
    final start = end.subtract(Duration(days: days));
    String two(int n) => n.toString().padLeft(2, '0');
    final label =
        '${start.year}-${two(start.month)}-${two(start.day)} ~ ${end.subtract(const Duration(days: 1)).year}-${two(end.subtract(const Duration(days: 1)).month)}-${two(end.subtract(const Duration(days: 1)).day)}';
    return buildForRange(db, start, end, label: label);
  }

  static Future<MonthlyReport> buildForMonth(AppDatabase db, DateTime anyDayInMonth) async {
    final start = monthStart(anyDayInMonth);
    final end = nextMonthStart(anyDayInMonth);
    final mk = monthKey(anyDayInMonth);
    return buildForRange(db, start, end, label: mk);
  }

  static Future<MonthlyReport> buildForYear(AppDatabase db, int year) async {
    final start = DateTime(year, 1, 1);
    final end = DateTime(year + 1, 1, 1);
    return buildForRange(db, start, end, label: '$year');
  }

  /// 计算某个时间点之前的“净额”(income-expense)，用于余额趋势（默认初始余额=0）
  static Future<int> netBefore(AppDatabase db, DateTime before) async {
    final query = db.select(db.transactions)
      ..where((t) => t.occurredAt.isSmallerThanValue(before));
    final rows = await query.get();
    int net = 0;
    for (final tx in rows) {
      final cents = tx.amountCents;
      net += (tx.direction == 'income') ? cents : -cents;
    }
    return net;
  }

  // ====== instance APIs used by Stats UI ======
  Future<MonthlyReport> getReportLast7Days() => buildForLastDays(db, 7);

  Future<MonthlyReport> getReportForMonth(DateTime anyDayInMonth) => buildForMonth(db, anyDayInMonth);

  Future<MonthlyReport> getReportForYear(int year) => buildForYear(db, year);

  /// 7日：每天结束时余额（单位：美元 double）
  Future<List<TrendPoint>> getDailyBalanceTrendLast7Days({DateTime? now}) async {
    final n = now ?? DateTime.now();
    final end = dayStart(n).add(const Duration(days: 1));
    final start = end.subtract(const Duration(days: 7));

    // 预取区间内交易，按日累计，提高性能
    final query = db.select(db.transactions)
      ..where((t) => t.occurredAt.isBetweenValues(start, end))
      ..orderBy([(t) => d.OrderingTerm(expression: t.occurredAt)]);
    final rows = await query.get();

    // start 前余额
    int balance = await netBefore(db, start);

    final dailyNet = <DateTime, int>{};
    for (final tx in rows) {
      final d0 = dayStart(tx.occurredAt);
      final delta = (tx.direction == 'income') ? tx.amountCents : -tx.amountCents;
      dailyNet[d0] = (dailyNet[d0] ?? 0) + delta;
    }

    String two(int v) => v.toString().padLeft(2, '0');

    final out = <TrendPoint>[];
    for (int i = 0; i < 7; i++) {
      final day = start.add(Duration(days: i));
      balance += (dailyNet[dayStart(day)] ?? 0);
      final label = '${two(day.month)}/${two(day.day)}';
      out.add(TrendPoint(label, balance / 100.0, date: day));
    }
    return out;
  }

  /// 月：每周结束时余额（周一~周日）
    /// 月：每日余额（按天显示）
  Future<List<TrendPoint>> getDailyBalanceTrendForMonth(DateTime anyDayInMonth) async {
    final mStart = monthStart(anyDayInMonth);
    final mEnd = nextMonthStart(anyDayInMonth);

    final query = db.select(db.transactions)
      ..where((t) => t.occurredAt.isBetweenValues(mStart, mEnd))
      ..orderBy([(t) => d.OrderingTerm(expression: t.occurredAt)]);
    final rows = await query.get();

    // 月初之前的余额
    int balance = await netBefore(db, mStart);

    final dailyNet = <DateTime, int>{};
    for (final tx in rows) {
      final d0 = dayStart(tx.occurredAt);
      final delta = (tx.direction == 'income') ? tx.amountCents : -tx.amountCents;
      dailyNet[d0] = (dailyNet[d0] ?? 0) + delta;
    }

    String two(int v) => v.toString().padLeft(2, '0');

    final out = <TrendPoint>[];
    DateTime cursor = mStart;
    while (cursor.isBefore(mEnd)) {
      balance += (dailyNet[dayStart(cursor)] ?? 0);
      final label = '${two(cursor.month)}/${two(cursor.day)}';
      out.add(TrendPoint(label, balance / 100.0, date: cursor));
      cursor = cursor.add(const Duration(days: 1));
    }

    // 避免只有 0/1 个点导致“竖线”
    if (out.length == 1) {
      out.insert(0, TrendPoint(out.first.label, out.first.value));
    }
    return out;
  }

  /// 年：每月结束时余额
  Future<List<TrendPoint>> getMonthlyBalanceTrendForYear(int year) async {
    final yStart = DateTime(year, 1, 1);
    final yEnd = DateTime(year + 1, 1, 1);

    final query = db.select(db.transactions)
      ..where((t) => t.occurredAt.isBetweenValues(yStart, yEnd))
      ..orderBy([(t) => d.OrderingTerm(expression: t.occurredAt)]);
    final rows = await query.get();

    int balance = await netBefore(db, yStart);

    // 每天净额 -> 这里直接按月累计也可，简单点按月 net
    final monthNet = <int, int>{}; // month -> net cents
    for (final tx in rows) {
      final m = tx.occurredAt.month;
      final delta = (tx.direction == 'income') ? tx.amountCents : -tx.amountCents;
      monthNet[m] = (monthNet[m] ?? 0) + delta;
    }

    final out = <TrendPoint>[];
    for (int m = 1; m <= 12; m++) {
      balance += (monthNet[m] ?? 0);
      out.add(TrendPoint(
      m.toString().padLeft(2, '0'),
      balance / 100.0,
      date: DateTime(year, m, 1),
    ));
    }
    return out;
  }

  // ====== local report archive I/O ======
  static Future<Directory> _reportsDir() async {
    final dir = await getApplicationDocumentsDirectory();
    final reports = Directory('${dir.path}/monthly_reports');
    if (!await reports.exists()) await reports.create(recursive: true);
    return reports;
  }

  static Future<File> _reportFile(String monthKey) async {
    final dir = await _reportsDir();
    return File('${dir.path}/$monthKey.json');
  }

  /// 启动时调用：如果跨月了，就把“上个月报告”保存到本地文件
  static Future<void> archiveLastMonthIfNeeded(AppDatabase db) async {
    final sp = await SharedPreferences.getInstance();
    final lastKey = sp.getString(_kLastArchivedMonth);

    final now = DateTime.now();
    final thisKey = monthKey(now);
    if (lastKey == thisKey) return;

    final lastMonth = DateTime(now.year, now.month - 1, 1);
    final report = await buildForMonth(db, lastMonth);
    final file = await _reportFile(monthKey(lastMonth));
    await file.writeAsString(jsonEncode(report.toJson()));

    await sp.setString(_kLastArchivedMonth, thisKey);
  }

  static Future<List<MonthlyReport>> loadAllReports() async {
    final dir = await _reportsDir();
    final files = dir
        .listSync()
        .whereType<File>()
        .where((f) => f.path.endsWith('.json'))
        .toList()
      ..sort((a, b) => b.path.compareTo(a.path));

    final out = <MonthlyReport>[];
    for (final f in files) {
      final txt = await f.readAsString();
      out.add(MonthlyReport.fromJson(jsonDecode(txt) as Map<String, dynamic>));
    }
    return out;
  }

  static Future<MonthlyReport?> loadReport(String monthKey) async {
    final f = await _reportFile(monthKey);
    if (!await f.exists()) return null;
    final txt = await f.readAsString();
    return MonthlyReport.fromJson(jsonDecode(txt) as Map<String, dynamic>);
  }

  static Future<void> deleteReport(String monthKey) async {
    final f = await _reportFile(monthKey);
    if (await f.exists()) await f.delete();
  }
}
