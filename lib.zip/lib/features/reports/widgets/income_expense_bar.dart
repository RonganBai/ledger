import 'package:flutter/material.dart';

/// 收支对比条（带动画，分割线会移动到最终比例位置）
///
/// 动画效果：
/// - 整体从左到右“扫入”
/// - 分割线从 50%（居中）平滑移动到最终比例位置
/// - 左右金额从 0 递增到最终值
class IncomeExpenseBar extends StatelessWidget {
  final int incomeCents;
  final int expenseCents;
  final String incomeLabel;
  final String expenseLabel;

  /// 动画时长
  final Duration duration;

  const IncomeExpenseBar({
    super.key,
    required this.incomeCents,
    required this.expenseCents,
    required this.incomeLabel,
    required this.expenseLabel,
    this.duration = const Duration(milliseconds: 1100),
  });

  String _money(double v) => v.toStringAsFixed(2);

  double _clamp01(double v) => v.clamp(0.0, 1.0);

  @override
  Widget build(BuildContext context) {
    final income = incomeCents.toDouble();
    final expense = expenseCents.toDouble();
    final total = income + expense;

    // 左边=支出，右边=收入
    final expenseRatio = total <= 0 ? 0.5 : (expense / total);
    // 分割线最终位置：左侧(支出)占比
    final splitTarget = expenseRatio.clamp(0.0, 1.0);

    const barHeight = 18.0;
    const radius = 14.0;
    const dividerW = 2.0;

    // 避免 withOpacity 弃用：alpha 0..255
    final redBg = Colors.red.withValues(alpha: 90);
    final greenBg = Colors.green.withValues(alpha: 90);

    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0, end: 1),
      duration: duration,
      curve: Curves.easeOutCubic,
      builder: (context, tRaw, _) {
        // 关键：避免浮点超界导致 Curves assert
        final t = _clamp01(tRaw);

        // 结尾轻微回弹：对整体进度再做一次曲线（靠近末尾更明显）
        final sweep = (t < 0.85)
            ? t
            : (0.85 +
                (Curves.easeOutBack.transform(_clamp01((t - 0.85) / 0.15)) *
                    0.15));

        // 分割线移动：从 50% -> splitTarget
        final moveT = Curves.easeOutCubic.transform(_clamp01(t));
        final split = (0.5 + (splitTarget - 0.5) * moveT).clamp(0.0, 1.0);

        // 金额递增
        final shownExpense = (expenseCents / 100.0) * sweep;
        final shownIncome = (incomeCents / 100.0) * sweep;

        return Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    expenseLabel,
                    textAlign: TextAlign.left,
                    style: Theme.of(context).textTheme.titleLarge,
                  ),
                ),
                Expanded(
                  child: Text(
                    incomeLabel,
                    textAlign: TextAlign.right,
                    style: Theme.of(context).textTheme.titleLarge,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),

            // ===== 条形扫入 + 分割线移动（加描边）=====
            Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(radius),
                border: Border.all(
                  width: 1.2,
                  color: Theme.of(context).dividerColor.withValues(alpha: 110),
                ),
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(radius),
                child: SizedBox(
                  height: barHeight,
                  child: LayoutBuilder(
                    builder: (context, c) {
                      final w = c.maxWidth;
                      final leftW = w * split;
                      final rightW = (w - leftW).clamp(0.0, w);

                      return Stack(
                        children: [
                          Positioned.fill(
                            child: ClipRect(
                              child: Align(
                                alignment: Alignment.centerLeft,
                                widthFactor: _clamp01(sweep),
                                child: Stack(
                                  children: [
                                    Positioned(
                                      left: 0,
                                      top: 0,
                                      bottom: 0,
                                      width: leftW,
                                      child: Container(color: redBg),
                                    ),
                                    Positioned(
                                      left: leftW,
                                      top: 0,
                                      bottom: 0,
                                      width: rightW,
                                      child: Container(color: greenBg),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                          Positioned.fill(
                            child: ClipRect(
                              child: Align(
                                alignment: Alignment.centerLeft,
                                widthFactor: _clamp01(sweep),
                                child: Stack(
                                  children: [
                                    Positioned(
                                      left: (leftW - dividerW / 2).clamp(0.0, w - dividerW),
                                      top: 0,
                                      bottom: 0,
                                      width: dividerW,
                                      child: Container(color: Colors.black54),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ],
                      );
                    },
                  ),
                ),
              ),
            ),

            const SizedBox(height: 8),

            // ===== 金额递增动画 =====
            Row(
              children: [
                Expanded(
                  child: Text(
                    '-\$${_money(shownExpense)}',
                    style: const TextStyle(
                      color: Colors.red,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                ),
                Expanded(
                  child: Text(
                    '+\$${_money(shownIncome)}',
                    textAlign: TextAlign.right,
                    style: const TextStyle(
                      color: Colors.green,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                ),
              ],
            ),
          ],
        );
      },
    );
  }
}
