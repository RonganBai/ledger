import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../../../l10n/tr.dart';

class TrendPoint {
  final String label;
  final double value;

  /// ✅ 新增：用于范围展示、7日星期映射、轴刻度更准
  final DateTime? date;

  const TrendPoint(this.label, this.value, {this.date});
}

/// Simple 1~2 line trend chart.
/// - If you only pass [data], it draws a single line.
/// - If you pass [secondary], it draws two lines.
///
/// ✅ 支持：日期范围展示、7日X轴星期化、Y轴金额刻度
class BalanceTrendLine extends StatefulWidget {
  final List<TrendPoint> data;
  final List<TrendPoint>? secondary;

  final String title;
  final String primaryLabel;
  final String secondaryLabel;

  /// ✅ 新增：是否播放动画
  final bool animate;
  /// ✅ 新增：动画时长
  final Duration duration;

  const BalanceTrendLine({
    super.key,
    required this.data,
    this.secondary,
    this.title = '余额趋势',
    this.primaryLabel = '余额',
    this.secondaryLabel = '支出',
    this.animate = true,
    this.duration = const Duration(milliseconds: 1000),
  });

  @override
  State<BalanceTrendLine> createState() => _BalanceTrendLineState();
}

class _BalanceTrendLineState extends State<BalanceTrendLine>
    with SingleTickerProviderStateMixin {
  late final AnimationController _ctl;
  late final Animation<double> _t;

  @override
  void initState() {
    super.initState();
    _ctl = AnimationController(vsync: this, duration: widget.duration);
    _t = CurvedAnimation(parent: _ctl, curve: Curves.easeOutCubic);

    if (widget.animate) {
      _ctl.forward(from: 0);
    } else {
      _ctl.value = 1;
    }
  }

  @override
  void didUpdateWidget(covariant BalanceTrendLine oldWidget) {
    super.didUpdateWidget(oldWidget);

    // ✅ 数据变了就重播（长度/数值变化都算）
    final dataChanged = oldWidget.data.length != widget.data.length ||
        oldWidget.secondary?.length != widget.secondary?.length ||
        !_sameSeries(oldWidget.data, widget.data) ||
        !_sameSeries(oldWidget.secondary, widget.secondary);

    if (dataChanged) {
      if (widget.animate) {
        _ctl
          ..duration = widget.duration
          ..forward(from: 0);
      } else {
        _ctl.value = 1;
      }
    }
  }

  bool _sameSeries(List<TrendPoint>? a, List<TrendPoint>? b) {
    if (a == null && b == null) return true;
    if (a == null || b == null) return false;
    if (a.length != b.length) return false;
    for (int i = 0; i < a.length; i++) {
      if (a[i].value != b[i].value || a[i].label != b[i].label) return false;
    }
    return true;
  }

  @override
  void dispose() {
    _ctl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final showTitle = (widget.title == '余额趋势')
        ? tr(context, en: 'Balance Trend', zh: '余额趋势')
        : widget.title;

    final showPrimary = (widget.primaryLabel == '余额')
        ? tr(context, en: 'Balance', zh: '余额')
        : widget.primaryLabel;

    final showSecondary = (widget.secondaryLabel == '支出')
        ? tr(context, en: 'Expense', zh: '支出')
        : widget.secondaryLabel;

    if (widget.data.isEmpty) return const SizedBox(height: 240);

    final all = <TrendPoint>[
      ...widget.data,
      if (widget.secondary != null) ...widget.secondary!,
    ];

    double maxV = all.first.value, minV = all.first.value;
    for (final p in all) {
      if (p.value > maxV) maxV = p.value;
      if (p.value < minV) minV = p.value;
    }

    final nice = _NiceScale(minV, maxV, ticks: 5);
    final yMin = nice.niceMin;
    final yMax = nice.niceMax;

    final rangeLabel = _buildRangeLabel(context, widget.data);

    return Card(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: BorderSide(
          width: 1.2,
          color: Theme.of(context).dividerColor.withValues(alpha: 110),
        ),
      ),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    showTitle,
                    style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                ),
                if (rangeLabel != null)
                  Text(
                    rangeLabel,
                    style: Theme.of(context).textTheme.labelMedium?.copyWith(
                          color: Theme.of(context)
                              .colorScheme
                              .onSurface
                              .withValues(alpha: 150),
                          fontWeight: FontWeight.w700,
                        ),
                  ),
              ],
            ),
            const SizedBox(height: 8),
            _Legend(
              primaryLabel: showPrimary,
              secondaryLabel: widget.secondary == null ? null : showSecondary,
            ),
            const SizedBox(height: 10),
            SizedBox(
              height: 130,
              width: double.infinity,
              child: AnimatedBuilder(
                animation: _t,
                builder: (_, __) {
                  return CustomPaint(
                    painter: _LinePainter(
                      primary: widget.data,
                      secondary: widget.secondary,
                      yMin: yMin,
                      yMax: yMax,
                      yTicks: nice.ticks,
                      languageCode: Localizations.localeOf(context).languageCode,
                      progress: _t.value, // ✅ 关键：0->1
                    ),
                    child: const SizedBox.expand(),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  // 你原来的 _buildRangeLabel 保持不变
  String? _buildRangeLabel(BuildContext context, List<TrendPoint> series) {
    final first = series.first.date;
    final last = series.last.date;
    if (first == null || last == null) return null;

    String two(int v) => v.toString().padLeft(2, '0');

    final sameYear = first.year == last.year;
    final sameMonth = sameYear && first.month == last.month;

    if (sameMonth) {
      return '${first.month}/${two(first.day)}–${last.month}/${two(last.day)}';
    }
    if (sameYear) {
      return '${first.month}/${two(first.day)}–${last.month}/${two(last.day)}';
    }
    return '${first.year}/${two(first.month)}/${two(first.day)}–'
        '${last.year}/${two(last.month)}/${two(last.day)}';
  }
}

class _Legend extends StatelessWidget {
  final String primaryLabel;
  final String? secondaryLabel;

  const _Legend({required this.primaryLabel, this.secondaryLabel});

  Widget _dot(Color c) => Container(
        width: 10,
        height: 10,
        decoration: BoxDecoration(color: c, shape: BoxShape.circle),
      );

  @override
  Widget build(BuildContext context) {
    final style = Theme.of(context).textTheme.labelMedium;
    return Row(
      children: [
        _dot(Colors.green),
        const SizedBox(width: 6),
        Text(primaryLabel, style: style),
        if (secondaryLabel != null) ...[
          const SizedBox(width: 14),
          _dot(Colors.red),
          const SizedBox(width: 6),
          Text(secondaryLabel!, style: style),
        ],
      ],
    );
  }
}

class _LinePainter extends CustomPainter {
  final List<TrendPoint> primary;
  final List<TrendPoint>? secondary;

  final double yMin;
  final double yMax;
  final int yTicks;
  final double progress; // 0..1

  final String languageCode;

  _LinePainter({
    required this.primary,
    required this.secondary,
    required this.yMin,
    required this.yMax,
    required this.yTicks,
    required this.languageCode,
    required this.progress,
  });

  List<int> _downsampleEvenly(List<int> sortedIdxs, {required int maxCount}) {
    if (sortedIdxs.length <= maxCount) return sortedIdxs;
    final out = <int>[];
    for (int k = 0; k < maxCount; k++) {
      final i = ((sortedIdxs.length - 1) * k / (maxCount - 1)).round();
      out.add(sortedIdxs[i]);
    }
    return out.toSet().toList()..sort();
  }

  bool _isMonthlySeries(List<TrendPoint> s) {
    if (s.length < 14) return false;
    final first = s.first.date;
    final last = s.last.date;
    if (first == null || last == null) return false;
    return first.year == last.year &&
        first.month == last.month &&
        (last.difference(first).inDays + 1) >= 20;
  }

  bool _isYearlySeries(List<TrendPoint> s) {
    final d0 = s.first.date;
    final d1 = s.last.date;
    if (d0 == null || d1 == null) return false;
    final spanDays = d1.difference(d0).inDays;
    // ✅ 更稳：跨度大于 ~7个月就当“年/年度趋势”
    return spanDays >= 200;
  }

  /// 月视图：给定总天数，选一个“好看的间隔”，让刻度 4~7 个之间且尽量均匀
  int _niceDayStep(int days) {
    const candidates = [2, 3, 4, 5, 6, 7, 10, 14];
    int best = 6;
    int bestScore = 1 << 30;

    for (final step in candidates) {
      final ticks = (days / step).floor() + 1;
      final score = (ticks - 6).abs() * 10 + (step - 6).abs();
      if (ticks >= 4 && ticks <= 7 && score < bestScore) {
        best = step;
        bestScore = score;
      }
    }
    return best;
  }

  @override
  void paint(Canvas canvas, Size size) {
    // paddings
    const leftPad = 44.0; // ✅ 给Y轴金额刻度留空间
    const rightPad = 12.0;
    const topPad = 10.0;
    const bottomPad = 26.0;

    final w = (size.width - leftPad - rightPad).clamp(1.0, double.infinity);
    final h = (size.height - topPad - bottomPad).clamp(1.0, double.infinity);

    // axis
    final axisPaint = Paint()
      ..color = Colors.black.withValues(alpha: 45)
      ..strokeWidth = 1;

    final gridPaint = Paint()
      ..color = Colors.black.withValues(alpha: 16)
      ..strokeWidth = 1;

    // y grid + labels
    final textStyle =
        const TextStyle(fontSize: 11, color: Colors.black54, height: 1.0);

    for (int i = 0; i < yTicks; i++) {
      final t = (yTicks == 1) ? 0.0 : i / (yTicks - 1);
      final y = topPad + (h * (1 - t));
      canvas.drawLine(Offset(leftPad, y), Offset(leftPad + w, y), gridPaint);

      final v = yMin + (yMax - yMin) * t;
      final label = _formatMoney(v);

      final tp = TextPainter(
        text: TextSpan(text: label, style: textStyle),
        textDirection: TextDirection.ltr,
      )..layout();

      tp.paint(canvas, Offset(leftPad - 8 - tp.width, y - tp.height / 2));
    }

    // axes lines
    canvas.drawLine(
        Offset(leftPad, topPad), Offset(leftPad, topPad + h), axisPaint);
    canvas.drawLine(Offset(leftPad, topPad + h), Offset(leftPad + w, topPad + h),
        axisPaint);

    void drawSeries(List<TrendPoint> series, Color color) {
      final n = series.length;
      if (n == 0) return;

      final stepX = (n <= 1) ? 0.0 : w / (n - 1);

      final line = Paint()
        ..color = color
        ..strokeWidth = 2
        ..style = PaintingStyle.stroke;

      final dot = Paint()
        ..color = color
        ..style = PaintingStyle.fill;

      final clipRight = leftPad + w * progress;

      canvas.save();
      canvas.clipRect(Rect.fromLTRB(leftPad, 0, clipRight + 2, size.height));

      final path = Path();
      for (int i = 0; i < n; i++) {
        final x = leftPad + i * stepX;
        final y = _mapY(series[i].value, topPad, h, yMin, yMax);

        if (i == 0) {
          path.moveTo(x, y);
        } else {
          path.lineTo(x, y);
        }

        if (x <= clipRight) {
          canvas.drawCircle(Offset(x, y), 3.4, dot);
        }
      }

      canvas.drawPath(path, line);
      canvas.restore();
    }

    drawSeries(primary, Colors.blue);
    if (secondary != null && secondary!.isNotEmpty) {
      drawSeries(secondary!, Colors.red);
    }

    _drawXLabels(canvas, size, leftPad, topPad, w, h, primary);
  }

  void _drawXLabels(Canvas canvas, Size size, double leftPad, double topPad,
      double w, double h, List<TrendPoint> series) {
    final n = series.length;
    if (n == 0) return;

    final stepX = (n <= 1) ? 0.0 : w / (n - 1);
    final yBase = topPad + h;

    final is7Days = n == 7 && series.every((e) => e.date != null);

    String labelAt(int i) {
      final p = series[i];

      // ✅ 7日：用星期
      if (is7Days) {
        final wd = p.date!.weekday; // Mon=1..Sun=7
        if (languageCode.toLowerCase().startsWith('zh')) {
          const map = {1: '一', 2: '二', 3: '三', 4: '四', 5: '五', 6: '六', 7: '日'};
          return map[wd] ?? '';
        } else {
          const map = {1: 'Mon', 2: 'Tue', 3: 'Wed', 4: 'Thu', 5: 'Fri', 6: 'Sat', 7: 'Sun'};
          return map[wd] ?? '';
        }
      }

      // ✅ 月：显示 月/日
      if (_isMonthlySeries(series) && p.date != null) {
    final d = p.date!;
    return '${d.day}';
  }

      // ✅ 年：显示 月
      if (_isYearlySeries(series) && p.date != null) {
        final d = p.date!;
        return languageCode.toLowerCase().startsWith('zh') ? '${d.month}月' : '${d.month}';
      }

      // 其它：沿用现有 label
      return p.label;
    }

    final idxs = <int>{};

    if (is7Days) {
      for (int i = 0; i < n; i++) idxs.add(i);
    } else if (_isYearlySeries(series)) {
    // ✅ 年：每个月一个刻度（同月只取一次）

    final seenMonth = <String>{}; // "YYYY-MM"

    for (int i = 0; i < n; i++) {
      final d = series[i].date;
      if (d == null) continue;

      final key = '${d.year}-${d.month.toString().padLeft(2, '0')}';
      if (seenMonth.contains(key)) continue;

      seenMonth.add(key);
      idxs.add(i);
    }

    // 防止跨多年的情况刻度过多（比如2年数据）
    if (idxs.length > 12) {
      final sorted = idxs.toList()..sort();
      idxs
        ..clear()
        ..addAll(_downsampleEvenly(sorted, maxCount: 12));
    }
  } else if (_isMonthlySeries(series)) {
      // ✅ 月：按天数选择间隔（4~7个），且尽量均匀
      final first = series.first.date!;
      final last = series.last.date!;
      final days = last.difference(first).inDays + 1;
      final stepDays = _niceDayStep(days);

      for (int i = 0; i < n; i++) {
        final d = series[i].date;
        if (d == null) continue;
        final dayIndex = d.difference(first).inDays; // 0-based
        if (dayIndex % stepDays == 0) idxs.add(i);
      }

      idxs.add(n - 1);

      if (idxs.length > 8) {
        final sorted = idxs.toList()..sort();
        idxs
          ..clear()
          ..addAll(_downsampleEvenly(sorted, maxCount: 8));
      }
    } else {
      // 其它跨度：均匀采样 4~7 个刻度
      final desired = math.min(7, math.max(4, (w / 70).floor()));
      final picks = <int>{0, n - 1};
      for (int k = 1; k < desired - 1; k++) {
        picks.add(((n - 1) * k / (desired - 1)).round());
      }
      idxs.addAll(picks);
    }

    final style = const TextStyle(fontSize: 11, color: Colors.black54);
    final tickPaint = Paint()
      ..color = Colors.black.withValues(alpha: 45)
      ..strokeWidth = 1;

    for (final i in idxs) {
      final x = leftPad + i * stepX;

      // tick
      canvas.drawLine(Offset(x, yBase), Offset(x, yBase + 4), tickPaint);

      final label = labelAt(i);
      final tp = TextPainter(
        text: TextSpan(text: label, style: style),
        textDirection: TextDirection.ltr,
      )..layout(maxWidth: 60);

      final dx = (x - tp.width / 2).clamp(0.0, size.width - tp.width);
      tp.paint(canvas, Offset(dx, yBase + 6));
    }
  }

  double _mapY(double v, double topPad, double h, double minV, double maxV) {
    final range = (maxV - minV).abs() < 1e-9 ? 1.0 : (maxV - minV);
    final t = ((v - minV) / range).clamp(0.0, 1.0);
    return topPad + (h * (1 - t));
  }

  String _formatMoney(double v) {
    final sign = v < 0 ? '-' : '';
    final abs = v.abs();

    if (abs >= 1000000) return '$sign\$${(abs / 1000000).toStringAsFixed(1)}M';
    if (abs >= 1000) return '$sign\$${(abs / 1000).toStringAsFixed(1)}k';

    return '$sign\$${abs.toStringAsFixed(0)}';
  }

  @override
  bool shouldRepaint(covariant _LinePainter old) {
    return old.primary != primary ||
        old.secondary != secondary ||
        old.yMin != yMin ||
        old.yMax != yMax ||
        old.yTicks != yTicks ||
        old.languageCode != languageCode ||
        old.progress != progress;
  }
}

/// 让Y轴刻度“更好看”（类似图表库的 nice scale）
class _NiceScale {
  final double niceMin;
  final double niceMax;
  final int ticks;

  _NiceScale(double min, double max, {this.ticks = 5})
      : assert(ticks >= 2),
        niceMin = _calcNiceMin(min, max, ticks),
        niceMax = _calcNiceMax(min, max, ticks);

  static double _calcNiceMin(double min, double max, int ticks) {
    final range = _niceNum(max - min, false);
    final step = _niceNum(range / (ticks - 1), true);
    return (min / step).floorToDouble() * step;
  }

  static double _calcNiceMax(double min, double max, int ticks) {
    final range = _niceNum(max - min, false);
    final step = _niceNum(range / (ticks - 1), true);
    return (max / step).ceilToDouble() * step;
  }

  static double _niceNum(double range, bool round) {
    final r = range.abs() < 1e-9 ? 1.0 : range.abs();
    final exp = math.log(r) / math.ln10;
    final pow10 = math.pow(10, exp.floor()).toDouble();
    final f = r / pow10;

    double nf;
    if (round) {
      if (f < 1.5) nf = 1;
      else if (f < 3) nf = 2;
      else if (f < 7) nf = 5;
      else nf = 10;
    } else {
      if (f <= 1) nf = 1;
      else if (f <= 2) nf = 2;
      else if (f <= 5) nf = 5;
      else nf = 10;
    }
    return nf * pow10;
  }
}