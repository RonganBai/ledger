import 'package:flutter/material.dart';
import '../../../l10n/tr.dart';
import '../models.dart';
import '../report_service.dart';
import 'balance_trend_line.dart';
import 'expense_pie.dart';
import 'income_expense_bar.dart';

/// 统计页（7日 / 月 / 年）
/// - 顶部：胶囊状收支条（IncomeExpenseBar）
/// - 中间：差值（income-expense）
/// - 折线：余额趋势（BalanceTrendLine，单线）
/// - 底部：支出饼图（ExpensePie）
/// - 支持左右滑动切换（PageView）
class MonthlyStatsSheet extends StatefulWidget {
  final ReportService service;

  const MonthlyStatsSheet({super.key, required this.service});

  @override
  State<MonthlyStatsSheet> createState() => _MonthlyStatsSheetState();
}

class _MonthlyStatsSheetState extends State<MonthlyStatsSheet> {
  int _index = 0;
  late final PageController _page;

  @override
  void initState() {
    super.initState();
    _page = PageController(initialPage: _index);
  }

  @override
  void dispose() {
    _page.dispose();
    super.dispose();
  }

  void _go(int i) {
    setState(() => _index = i);
    _page.animateToPage(
      i,
      duration: const Duration(milliseconds: 240),
      curve: Curves.easeOut,
    );
  }

  @override
  Widget build(BuildContext context) {
    final tabs = [
    tr(context, en: '7D', zh: '7日'),
    tr(context, en: 'Month', zh: '月'),
    tr(context, en: 'Year', zh: '年'),
  ];
    return Column(
      children: [
        const SizedBox(height: 12),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12),
          child: _SegTabs(
            tabs: tabs,
            index: _index,
            onChanged: _go,
          ),
        ),
        const SizedBox(height: 12),
        Expanded(
          child: PageView(
            controller: _page,
            onPageChanged: (i) => setState(() => _index = i),
            children: [
              _PeriodPage(
                title: '7日',
                reportFuture: widget.service.getReportLast7Days(),
                balanceTrendFuture: widget.service.getDailyBalanceTrendLast7Days(),
              ),
              _PeriodPage(
                title: '月',
                reportFuture: widget.service.getReportForMonth(DateTime.now()),
                // ✅ 月趋势改为每日
                balanceTrendFuture: widget.service.getDailyBalanceTrendForMonth(DateTime.now()),
              ),
              _PeriodPage(
                title: '年',
                reportFuture: widget.service.getReportForYear(DateTime.now().year),
                balanceTrendFuture: widget.service.getMonthlyBalanceTrendForYear(DateTime.now().year),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

/// ✅ 顶部更明显的分段导航：无对勾，靠高光+文字变色
class _SegTabs extends StatelessWidget {
  final List<String> tabs;
  final int index;
  final ValueChanged<int> onChanged;

  const _SegTabs({
    required this.tabs,
    required this.index,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final border = Theme.of(context).dividerColor.withValues(alpha: 120);

    return LayoutBuilder(
      builder: (context, constraints) {
        final tabWidth = constraints.maxWidth / tabs.length;

        return Container(
          height: 44, // ✅ 控制整体高度
          decoration: BoxDecoration(
            color: scheme.surface,
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: border, width: 1.2),
          ),
          child: Stack(
            children: [
              // ✅ 滑动高光块
              AnimatedPositioned(
                duration: const Duration(milliseconds: 220),
                curve: Curves.easeOut,
                left: tabWidth * index + 10,
                top: 4,
                bottom: 4,
                width: tabWidth - 20,
                child: Container(
                  decoration: BoxDecoration(
                    color: scheme.secondary,
                    borderRadius: BorderRadius.circular(20),
                  ),
                ),
              ),

              Row(
                children: List.generate(tabs.length, (i) {
                  final selected = index == i;
                  return Expanded(
                    child: InkWell(
                      borderRadius: BorderRadius.circular(24),
                      onTap: () => onChanged(i),
                      child: Center(
                        child: AnimatedDefaultTextStyle(
                          duration: const Duration(milliseconds: 180),
                          style: TextStyle(
                            fontSize: 15,
                            fontWeight: FontWeight.w700,
                            color: selected
                                ? scheme.onPrimary
                                : scheme.onSurface.withValues(alpha: 160),
                          ),
                          child: Text(tabs[i]),
                        ),
                      ),
                    ),
                  );
                }),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _PeriodPage extends StatelessWidget {
  final String title;
  final Future<MonthlyReport> reportFuture;
  final Future<List<TrendPoint>> balanceTrendFuture;

  const _PeriodPage({
    required this.title,
    required this.reportFuture,
    required this.balanceTrendFuture,
  });

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<MonthlyReport>(
      future: reportFuture,
      builder: (context, rep) {
        if (!rep.hasData) {
          return const Center(child: CircularProgressIndicator());
        }
        final r = rep.data!;

        final diffCents = r.incomeCents - r.expenseCents;
        final diffColor = diffCents >= 0 ? Colors.green : Colors.red;
        final diffAbs = (diffCents.abs() / 100.0).toStringAsFixed(2);
        final diffText = '${diffCents >= 0 ? '+' : '-'}\$$diffAbs';

        return SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(12, 0, 12, 18),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  // 左边：收支条
                  Expanded(
                    child: IncomeExpenseBar(
                      incomeCents: r.incomeCents,
                      expenseCents: r.expenseCents,
                      incomeLabel: tr(context, en: 'Income', zh: '收入'),
                      expenseLabel: tr(context, en: 'Expense', zh: '支出'),
                    ),
                  ),

                  const SizedBox(width: 12),

                  // 右边：净收入
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(
                        width: 1.2,
                        color: Theme.of(context).dividerColor.withValues(alpha: 140),
                      ),
                      color: Theme.of(context).colorScheme.surface,
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(tr(context, en: 'Net', zh: '净收入'),),
                        const SizedBox(height: 4),
                        Text(
                          diffText,
                          style: Theme.of(context).textTheme.titleMedium?.copyWith(
                                fontWeight: FontWeight.w900,
                                color: diffColor,
                              ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 12),

              FutureBuilder<List<TrendPoint>>(
                future: balanceTrendFuture,
                builder: (context, snap) {
                  if (!snap.hasData) {
                    return const SizedBox(
                      height: 240,
                      child: Center(child: CircularProgressIndicator()),
                    );
                  }
                  final data = snap.data!;
                  return BalanceTrendLine(
                    data: data,
                    primaryLabel: '余额',
                  );
                },
              ),

              const SizedBox(height: 18),

              ExpensePie(expenseByCategoryCents: r.expenseByCategoryCents),
            ],
          ),
        );
      },
    );
  }
}