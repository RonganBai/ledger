import 'package:flutter/material.dart';

import '../../data/db/app_database.dart';
import '../../l10n/tr.dart';

import 'models.dart';
import 'report_detail_page.dart';
import 'report_service.dart';

class HistoryPage extends StatefulWidget {
  final AppDatabase db;
  const HistoryPage({super.key, required this.db});

  @override
  State<HistoryPage> createState() => _HistoryPageState();
}

class _HistoryPageState extends State<HistoryPage> {
  late Future<List<MonthlyReport>> _future;

  @override
  void initState() {
    super.initState();
    _future = _load();
  }

  Future<List<MonthlyReport>> _load() async {
    // ✅ 关键：跨月时自动把“上个月”归档到本地文件
    await ReportService.archiveLastMonthIfNeeded(widget.db);

    // ✅ 读取本地所有月报 json
    return ReportService.loadAllReports();
  }

  void _reload() {
    setState(() {
      _future = _load();
    });
  }

  String _money(int cents) {
    final v = cents.abs() / 100.0;
    return (cents >= 0 ? '\$' : '-\$') + v.toStringAsFixed(2);
  }

  Future<void> _delete(BuildContext context, String monthKey) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(tr(context, en: 'Delete report?', zh: '删除月报？')),
        content: Text(tr(
          context,
          en: 'This will remove the archived report file for $monthKey.',
          zh: '这会删除 $monthKey 的历史月报文件（不可恢复）。',
        )),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: Text(tr(context, en: 'Cancel', zh: '取消')),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: Text(tr(context, en: 'Delete', zh: '删除')),
          ),
        ],
      ),
    );

    if (ok == true) {
      await ReportService.deleteReport(monthKey);
      if (mounted) _reload();
    }
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;

    return Scaffold(
      appBar: AppBar(
        title: Text(tr(context, en: 'History', zh: '历史记录')),
        actions: [
          IconButton(
            tooltip: tr(context, en: 'Refresh', zh: '刷新'),
            onPressed: _reload,
            icon: const Icon(Icons.refresh),
          ),
        ],
      ),
      body: FutureBuilder<List<MonthlyReport>>(
        future: _future,
        builder: (context, snap) {
          if (snap.connectionState != ConnectionState.done) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snap.hasError) {
            return Center(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Text('Error: ${snap.error}'),
              ),
            );
          }

          final list = snap.data ?? const <MonthlyReport>[];
          if (list.isEmpty) {
            return Center(
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Text(
                  tr(
                    context,
                    en: 'No archived monthly reports yet.\n\nTip: After you enter a new month, the app will archive the previous month automatically.',
                    zh: '还没有历史月报。\n\n提示：当你跨月进入新月份时，App 会自动把上个月归档成历史月报。',
                  ),
                  textAlign: TextAlign.center,
                  style: Theme.of(context).textTheme.bodyLarge,
                ),
              ),
            );
          }

          return ListView.separated(
            padding: const EdgeInsets.all(12),
            itemCount: list.length,
            separatorBuilder: (_, __) => const SizedBox(height: 8),
            itemBuilder: (context, i) {
              final r = list[i];
              final net = r.netCents;
              final netColor = net >= 0 ? Colors.green : Colors.red;

              return Card(
                child: ListTile(
                  title: Text(
                    r.monthKey,
                    style: const TextStyle(fontWeight: FontWeight.w900),
                  ),
                  subtitle: Padding(
                    padding: const EdgeInsets.only(top: 6),
                    child: Wrap(
                      spacing: 10,
                      runSpacing: 6,
                      children: [
                        Text(
                          '${tr(context, en: 'Income', zh: '收入')}: ${_money(r.incomeCents)}',
                          style: TextStyle(color: scheme.onSurfaceVariant),
                        ),
                        Text(
                          '${tr(context, en: 'Expense', zh: '支出')}: ${_money(r.expenseCents)}',
                          style: TextStyle(color: scheme.onSurfaceVariant),
                        ),
                      ],
                    ),
                  ),
                  trailing: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Text(
                        _money(net),
                        style: TextStyle(
                          fontWeight: FontWeight.w900,
                          color: netColor,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        tr(context, en: 'Tap to view', zh: '点按查看'),
                        style: TextStyle(fontSize: 11, color: scheme.onSurfaceVariant),
                      ),
                    ],
                  ),
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => ReportDetailPage(report: r),
                      ),
                    );
                  },
                  onLongPress: () => _delete(context, r.monthKey),
                ),
              );
            },
          );
        },
      ),
    );
  }
}