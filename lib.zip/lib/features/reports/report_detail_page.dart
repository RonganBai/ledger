import 'package:flutter/material.dart';
import '../../l10n/tr.dart';
import '../../l10n/category_i18n.dart';
import 'models.dart';
import 'widgets/income_expense_bar.dart';
import 'widgets/expense_pie.dart';

class ReportDetailPage extends StatelessWidget {
  final MonthlyReport report;
  const ReportDetailPage({super.key, required this.report});

  String _two(int n) => n.toString().padLeft(2, '0');

  String _dayKey(DateTime dt) => '${dt.year}-${_two(dt.month)}-${_two(dt.day)}';

  String _catLabel(BuildContext context, String key) {
    if (key == '__other__') return tr(context, en: 'Other', zh: '其他');
    return categoryLabel(context, key);
  }

  @override
  Widget build(BuildContext context) {
    final net = report.netCents / 100.0;
    final netColor = net >= 0 ? Colors.green : Colors.red;

    final txs = List<MonthlyTx>.from(report.transactions)
      ..sort((a, b) => b.occurredAt.compareTo(a.occurredAt)); // newest first

    final groups = <String, List<MonthlyTx>>{};
    for (final t in txs) {
      final k = _dayKey(t.occurredAt);
      (groups[k] ??= []).add(t);
    }
    final groupKeys = groups.keys.toList()..sort((a, b) => b.compareTo(a));

    return Scaffold(
      appBar: AppBar(
        title: Text('${tr(context, en: 'Report', zh: '报告')} ${report.monthKey}'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          IncomeExpenseBar(
            incomeCents: report.incomeCents,
            expenseCents: report.expenseCents,
            expenseLabel: tr(context, en: 'Expense', zh: '支出'),
            incomeLabel: tr(context, en: 'Income', zh: '收入'),
          ),
          const SizedBox(height: 10),
          Center(
            child: Text(
              net >= 0 ? '+\$${net.toStringAsFixed(2)}' : '-\$${(-net).toStringAsFixed(2)}',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: netColor),
            ),
          ),
          const SizedBox(height: 14),

          // 统计图
          Text(
            tr(context, en: 'Spending Summary', zh: '消费统计'),
            style: const TextStyle(fontWeight: FontWeight.w900),
          ),
          const SizedBox(height: 8),
          ExpensePie(expenseByCategoryCents: report.expenseByCategoryCents),

          const SizedBox(height: 18),

          // 明细
          Text(
            tr(context, en: 'Details', zh: '消费明细'),
            style: const TextStyle(fontWeight: FontWeight.w900),
          ),
          const SizedBox(height: 8),

          if (txs.isEmpty)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 20),
              child: Text(
                tr(
                  context,
                  en: 'No transaction details saved in this report yet.',
                  zh: '该月报还没有保存消费明细（更新后跨月生成的月报会包含明细）。',
                ),
              ),
            )
          else
            ...groupKeys.expand((day) {
              final list = groups[day]!;
              return [
                Padding(
                  padding: const EdgeInsets.fromLTRB(2, 12, 2, 6),
                  child: Text(
                    day,
                    style: TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w900,
                      color: Theme.of(context).colorScheme.onSurfaceVariant,
                    ),
                  ),
                ),
                ...list.map((t) {
                  final isIncome = t.direction == 'income';
                  final amt = t.amountCents / 100.0;
                  final amtStr = (isIncome ? '+\$' : '-\$') + amt.abs().toStringAsFixed(2);
                  final amtColor = isIncome ? Colors.green : Colors.red;

                  final timeStr = '${_two(t.occurredAt.hour)}:${_two(t.occurredAt.minute)}';

                  // ✅ 这里：merchant 为空时，用翻译后的分类名
                  final title = (t.merchant != null && t.merchant!.trim().isNotEmpty)
                      ? t.merchant!.trim()
                      : _catLabel(context, t.categoryName);

                  // ✅ 这里：副标题里的分类名也翻译
                  final subtitleParts = <String>[
                    timeStr,
                    _catLabel(context, t.categoryName),
                    if (t.memo != null && t.memo!.trim().isNotEmpty) t.memo!.trim(),
                  ];

                  return Card(
                    margin: const EdgeInsets.symmetric(vertical: 4),
                    child: ListTile(
                      leading: Icon(
                        isIncome ? Icons.arrow_downward : Icons.arrow_upward,
                        color: amtColor,
                      ),
                      title: Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
                      subtitle: Text(subtitleParts.join(' · ')),
                      trailing: Text(
                        amtStr,
                        style: TextStyle(fontWeight: FontWeight.w900, color: amtColor),
                      ),
                    ),
                  );
                }),
              ];
            }).toList(),
        ],
      ),
    );
  }
}