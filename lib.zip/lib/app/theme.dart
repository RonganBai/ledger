import 'package:flutter/material.dart';

ThemeData buildTheme() {
  const seed = Color(0xFF4F46E5);

  final scheme = ColorScheme.fromSeed(
    seedColor: seed,
    brightness: Brightness.light,
  );

  return ThemeData(
    useMaterial3: true,
    colorScheme: scheme,
    scaffoldBackgroundColor: const Color(0xFFF6F7FB),

    // ===== AppBar =====
    appBarTheme: AppBarTheme(
      elevation: 0,
      centerTitle: false,
      backgroundColor: const Color(0xFFF6F7FB),
      foregroundColor: scheme.onSurface,
      titleTextStyle: TextStyle(
        fontSize: 18,
        fontWeight: FontWeight.w800,
        color: scheme.onSurface,
      ),
    ),

    // ===== Card =====
    cardTheme: const CardThemeData(
      elevation: 0,
      color: Colors.white,
      // CardThemeData 的 shape 也支持 RoundedRectangleBorder
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.all(Radius.circular(20)),
      ),
    ),

    // ===== BottomSheet =====
    bottomSheetTheme: const BottomSheetThemeData(
      showDragHandle: true,
      backgroundColor: Colors.transparent,
    ),

    // ===== Chip =====
    chipTheme: ChipThemeData(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(999),
      ),
      side: BorderSide(
        color: Colors.black.withValues(alpha: 0.08),
      ),
      labelStyle: const TextStyle(
        fontWeight: FontWeight.w700,
      ),
    ),

    // ===== Input =====
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: Colors.white,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(16),
        borderSide: BorderSide.none,
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(16),
        borderSide: BorderSide(
          color: Colors.black.withValues(alpha: 0.08),
        ),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(16),
        borderSide: BorderSide(
          color: scheme.primary,
          width: 1.4,
        ),
      ),
    ),

    // ===== Filled Button =====
    filledButtonTheme: FilledButtonThemeData(
      style: FilledButton.styleFrom(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
        ),
        padding: const EdgeInsets.symmetric(
          horizontal: 16,
          vertical: 14,
        ),
        textStyle: const TextStyle(
          fontWeight: FontWeight.w800,
        ),
      ),
    ),

    // ===== Text Theme 微调 =====
    // ===== Text Theme（统一标题规格）=====
    textTheme: const TextTheme(
      // ✅ 统一卡片标题规格（余额趋势 / 支出占比 / 收入 / 支出）
      // 你希望“余额趋势”这种规格：更大、更粗 -> 18 / w900
      titleLarge: TextStyle(fontSize: 18, fontWeight: FontWeight.w900),

      // 次级标题（可选）
      titleMedium: TextStyle(fontSize: 16, fontWeight: FontWeight.w800),

      bodyMedium: TextStyle(fontWeight: FontWeight.w500),
    ),
  );
}