import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';

import '../data/db/app_database.dart';
import '../features/ledger/ledger_home.dart';
import '../ui/pet/pet_overlay.dart';

import '../ui/pet/pet_config.dart';
import '../ui/pet/pet_overlay.dart';

import 'theme.dart';

class MyApp extends StatefulWidget {
  final AppDatabase db;
  const MyApp({super.key, required this.db});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  Locale? _locale;  // 改成 nullable，不设默认

  @override
  void initState() {
    super.initState();
    PetConfig.I.load();
  }

  void _toggleLocale() {
    setState(() {
      final currentCode =
          _locale?.languageCode ??
          WidgetsBinding.instance.platformDispatcher.locale.languageCode;

      _locale =
          currentCode == 'zh'
              ? const Locale('en')
              : const Locale('zh');
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      builder: (context, child) {
        return Listener(
          behavior: HitTestBehavior.translucent,
          onPointerDown: (_) {
            // 如果当前已经没焦点，不会有副作用
            FocusManager.instance.primaryFocus?.unfocus();
          },
          child: Stack(
            children: [
              if (child != null) child,
              AnimatedBuilder(
                animation: PetConfig.I,
                builder: (_, __) {
                  return PetConfig.I.enabled
                      ? const PetOverlay()
                      : const SizedBox.shrink();
                },
              ),
            ],
          ),
        );
      },
      debugShowCheckedModeBanner: false,
      title: 'Ledger',
      locale: _locale,
      supportedLocales: const [Locale('en'), Locale('zh')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      theme: buildTheme(),
      home: LedgerHome(db: widget.db, onToggleLocale: _toggleLocale),
    );
  }
}