import 'package:shared_preferences/shared_preferences.dart';

class Settings {
  static const _kMinBalance = 'min_balance';
  static const _kMaxBalance = 'max_balance';

  static Future<double?> getMinBalance() async {
    final sp = await SharedPreferences.getInstance();
    return sp.containsKey(_kMinBalance) ? sp.getDouble(_kMinBalance) : null;
  }

  static Future<double?> getMaxBalance() async {
    final sp = await SharedPreferences.getInstance();
    return sp.containsKey(_kMaxBalance) ? sp.getDouble(_kMaxBalance) : null;
  }

  static Future<void> setMinBalance(double? v) async {
    final sp = await SharedPreferences.getInstance();
    if (v == null) {
      await sp.remove(_kMinBalance);
    } else {
      await sp.setDouble(_kMinBalance, v);
    }
  }

  static Future<void> setMaxBalance(double? v) async {
    final sp = await SharedPreferences.getInstance();
    if (v == null) {
      await sp.remove(_kMaxBalance);
    } else {
      await sp.setDouble(_kMaxBalance, v);
    }
  }
}