import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../data/db/app_database.dart';
import '../features/ledger/ledger_home.dart';
import '../ui/pet/pet_config.dart';
import '../ui/pet/pet_overlay.dart';
import 'theme.dart';

class MyApp extends StatefulWidget {
  final AppDatabase db;

  const MyApp({super.key, required this.db});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  static const _kDarkModePref = 'app_dark_mode';
  static const _kThemeStylePref = 'app_theme_style';
  static const _kThemeBgImagePref = 'app_theme_bg_image';
  Locale _locale = const Locale('zh');
  bool _darkMode = false;
  AppThemeStyle _themeStyle = AppThemeStyle.indigo;
  String? _themeBgImagePath;

  @override
  void initState() {
    super.initState();
    PetConfig.I.load();
    _loadThemePrefs();
  }

  void _toggleLocale() {
    setState(() {
      _locale = _locale.languageCode == 'zh'
          ? const Locale('en')
          : const Locale('zh');
    });
  }

  Future<void> _loadThemePrefs() async {
    final prefs = await SharedPreferences.getInstance();
    final dark = prefs.getBool(_kDarkModePref) ?? false;
    final style = appThemeStyleFromId(prefs.getString(_kThemeStylePref));
    final imagePath = prefs.getString(_kThemeBgImagePref);
    final imageExists = imagePath != null && File(imagePath).existsSync();
    if (!mounted) return;
    setState(() {
      _darkMode = dark;
      _themeStyle = style;
      _themeBgImagePath = imageExists ? imagePath : null;
    });
  }

  Future<void> _toggleTheme() async {
    final next = !_darkMode;
    setState(() => _darkMode = next);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_kDarkModePref, next);
  }

  Future<void> _setThemeStyle(AppThemeStyle style) async {
    if (_themeStyle == style) return;
    setState(() => _themeStyle = style);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_kThemeStylePref, appThemeStyleId(style));
  }

  Future<void> _setThemeBackgroundImagePath(String? path) async {
    final prevPath = _themeBgImagePath;
    setState(() => _themeBgImagePath = path);

    final prefs = await SharedPreferences.getInstance();
    if (path == null || path.isEmpty) {
      await prefs.remove(_kThemeBgImagePref);
    } else {
      await prefs.setString(_kThemeBgImagePref, path);
    }

    if (prevPath != null && prevPath != path) {
      try {
        final oldFile = File(prevPath);
        if (await oldFile.exists()) {
          await oldFile.delete();
        }
      } catch (_) {
        // Ignore failed cleanup; new path is already persisted.
      }
    }
  }

  Widget _buildThemeBackdrop() {
    final imagePath = _themeBgImagePath;
    if (imagePath == null || imagePath.isEmpty) {
      return DecoratedBox(
        decoration: appBackdropDecoration(
          style: _themeStyle,
          isDarkMode: _darkMode,
        ),
      );
    }

    final file = File(imagePath);
    if (!file.existsSync()) {
      return DecoratedBox(
        decoration: appBackdropDecoration(
          style: _themeStyle,
          isDarkMode: _darkMode,
        ),
      );
    }

    return Stack(
      fit: StackFit.expand,
      children: [
        Image.file(file, fit: BoxFit.cover),
        DecoratedBox(
          decoration: appImageOverlayDecoration(
            style: _themeStyle,
            isDarkMode: _darkMode,
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final hasCustomBg =
        _themeBgImagePath != null && _themeBgImagePath!.isNotEmpty;
    return MaterialApp(
      builder: (context, child) {
        return Listener(
          behavior: HitTestBehavior.translucent,
          onPointerDown: (_) => FocusManager.instance.primaryFocus?.unfocus(),
          child: Stack(
            children: [
              Positioned.fill(child: _buildThemeBackdrop()),
              child ?? const SizedBox.shrink(),
              AnimatedBuilder(
                animation: PetConfig.I,
                builder: (context, child) => PetConfig.I.enabled
                    ? const PetOverlay()
                    : const SizedBox.shrink(),
              ),
            ],
          ),
        );
      },
      debugShowCheckedModeBanner: false,
      title: 'Ledger',
      locale: _locale,
      supportedLocales: const [Locale('en'), Locale('zh')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      theme: buildLightTheme(
        style: _themeStyle,
        hasCustomBackgroundImage: hasCustomBg,
      ),
      darkTheme: buildDarkTheme(
        style: _themeStyle,
        hasCustomBackgroundImage: hasCustomBg,
      ),
      themeMode: _darkMode ? ThemeMode.dark : ThemeMode.light,
      home: LedgerHome(
        db: widget.db,
        onToggleLocale: _toggleLocale,
        onToggleTheme: _toggleTheme,
        isDarkMode: _darkMode,
        themeStyle: _themeStyle,
        onThemeStyleChanged: _setThemeStyle,
        themeBackgroundImagePath: _themeBgImagePath,
        onThemeBackgroundImageChanged: _setThemeBackgroundImagePath,
      ),
    );
  }
}
