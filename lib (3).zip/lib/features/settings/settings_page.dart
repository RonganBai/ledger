import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../app/settings.dart';
import '../../app/theme.dart';
import '../../data/db/app_database.dart';
import '../../l10n/tr.dart';
import 'import_export_service.dart';
import '../../ui/pet/pet_config.dart';

enum QuickActionKey {
  stats,
  history,
  categories,
  settings,
  switchAccount,
  manageAccounts,
  recurring,
}

String qaLabel(BuildContext context, QuickActionKey k) {
  switch (k) {
    case QuickActionKey.stats:
      return tr(context, en: 'Stats', zh: '统计');
    case QuickActionKey.history:
      return tr(context, en: 'History', zh: '历史');
    case QuickActionKey.categories:
      return tr(context, en: 'Categories', zh: '分类');
    case QuickActionKey.settings:
      return tr(context, en: 'Settings', zh: '设置');
    case QuickActionKey.switchAccount:
      return tr(context, en: 'Switch Account', zh: '切换账户');
    case QuickActionKey.manageAccounts:
      return tr(context, en: 'Manage Accounts', zh: '账户管理');
    case QuickActionKey.recurring:
      return tr(context, en: 'Recurring', zh: '周期交易');
  }
}

IconData qaIcon(QuickActionKey k) {
  switch (k) {
    case QuickActionKey.stats:
      return Icons.bar_chart_rounded;
    case QuickActionKey.history:
      return Icons.history_rounded;
    case QuickActionKey.categories:
      return Icons.category_rounded;
    case QuickActionKey.settings:
      return Icons.settings_rounded;
    case QuickActionKey.switchAccount:
      return Icons.swap_horiz_rounded;
    case QuickActionKey.manageAccounts:
      return Icons.account_balance_wallet_rounded;
    case QuickActionKey.recurring:
      return Icons.repeat_rounded;
  }
}

String themeStyleLabel(BuildContext context, AppThemeStyle style) {
  switch (style) {
    case AppThemeStyle.indigo:
      return tr(context, en: 'Indigo', zh: '靛蓝');
    case AppThemeStyle.forest:
      return tr(context, en: 'Forest', zh: '森林');
    case AppThemeStyle.sunset:
      return tr(context, en: 'Sunset', zh: '夕阳');
    case AppThemeStyle.ocean:
      return tr(context, en: 'Ocean', zh: '海洋');
  }
}

class SettingsPage extends StatefulWidget {
  final AppDatabase db;
  final int accountId;
  final VoidCallback? onToggleLocale;
  final bool isDarkMode;
  final VoidCallback? onToggleThemeMode;
  final AppThemeStyle activeThemeStyle;
  final ValueChanged<AppThemeStyle>? onThemeStyleChanged;
  final String? themeBackgroundImagePath;
  final ValueChanged<String?>? onThemeBackgroundImageChanged;

  const SettingsPage({
    super.key,
    required this.db,
    required this.accountId,
    this.onToggleLocale,
    required this.isDarkMode,
    this.onToggleThemeMode,
    required this.activeThemeStyle,
    this.onThemeStyleChanged,
    this.themeBackgroundImagePath,
    this.onThemeBackgroundImageChanged,
  });

  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage>
    with SingleTickerProviderStateMixin {
  bool _loading = true;
  bool _suppressAmountListener = false;

  bool _lowBalanceReminderOn = false;
  final TextEditingController _lowBalanceCtrl = TextEditingController();
  QuickActionKey _slot3 = QuickActionKey.stats;
  QuickActionKey _slot4 = QuickActionKey.history;
  bool _themeImageBusy = false;

  Timer? _debounce;

  @override
  void initState() {
    super.initState();
    _load();
    _lowBalanceCtrl.addListener(_onAmountChanged);
  }

  Future<void> _load() async {
    final minB = await Settings.getMinBalance(accountId: widget.accountId);
    _lowBalanceReminderOn = minB != null;
    _suppressAmountListener = true;
    _lowBalanceCtrl.text = minB == null ? '' : minB.toStringAsFixed(2);
    _suppressAmountListener = false;

    // Home quick actions (Button 3 & 4). Default: Stats + History.
    const kQaSlot3 = 'qa_slot3';
    const kQaSlot4 = 'qa_slot4';
    try {
      final p = await SharedPreferences.getInstance();
      final s3 = p.getString(kQaSlot3);
      final s4 = p.getString(kQaSlot4);
      _slot3 = QuickActionKey.values.firstWhere(
        (e) => e.name == s3,
        orElse: () => QuickActionKey.stats,
      );
      _slot4 = QuickActionKey.values.firstWhere(
        (e) => e.name == s4,
        orElse: () => QuickActionKey.history,
      );
      if (_slot3 == _slot4) {
        _slot4 = QuickActionKey.values.firstWhere(
          (e) => e != _slot3,
          orElse: () => QuickActionKey.history,
        );
      }
    } catch (_) {
      // keep defaults
    }

    if (!mounted) return;
    setState(() => _loading = false);
  }

  void _toast(String msg, {IconData icon = Icons.info_outline}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            Icon(icon, size: 18),
            const SizedBox(width: 8),
            Expanded(child: Text(msg)),
          ],
        ),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  void _onAmountChanged() {
    if (_suppressAmountListener || !_lowBalanceReminderOn) return;

    _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 450), () async {
      final raw = _lowBalanceCtrl.text.trim();
      if (raw.isEmpty) return;

      final v = double.tryParse(raw.replaceAll(',', ''));
      if (v == null) return;

      await Settings.setMinBalance(v, accountId: widget.accountId);
    });
  }

  Future<void> _turnOnAndAutoSave() async {
    final raw = _lowBalanceCtrl.text.trim();
    final v = double.tryParse(raw.isEmpty ? '0' : raw.replaceAll(',', '')) ?? 0;

    // If user hasn't set, put a sensible default.
    final saved = v <= 0 ? 100.0 : v;

    _suppressAmountListener = true;
    _lowBalanceCtrl.text = saved.toStringAsFixed(2);
    _suppressAmountListener = false;
    await Settings.setMinBalance(saved, accountId: widget.accountId);

    if (!mounted) return;
    _toast(
      tr(context, en: 'Reminder on', zh: '提醒已开启'),
      icon: Icons.notifications_active,
    );
  }

  Future<void> _turnOffAndClear() async {
    await Settings.setMinBalance(null, accountId: widget.accountId);
    _suppressAmountListener = true;
    _lowBalanceCtrl.text = '';
    _suppressAmountListener = false;

    if (!mounted) return;
    _toast(
      tr(context, en: 'Reminder off', zh: '提醒已关闭'),
      icon: Icons.notifications_off,
    );
  }

  Future<void> _saveQuickActions() async {
    const kQaSlot3 = 'qa_slot3';
    const kQaSlot4 = 'qa_slot4';
    final p = await SharedPreferences.getInstance();
    await p.setString(kQaSlot3, _slot3.name);
    await p.setString(kQaSlot4, _slot4.name);
    if (!mounted) return;
    _toast(
      tr(context, en: 'Quick actions saved', zh: '快捷按键已保存'),
      icon: Icons.check_circle_outline,
    );
  }

  String _extOf(String p) {
    final slash = p.lastIndexOf(RegExp(r'[\\/]'));
    final dot = p.lastIndexOf('.');
    if (dot <= slash || dot < 0) return '.jpg';
    return p.substring(dot).toLowerCase();
  }

  Future<void> _pickThemeBackgroundImage() async {
    if (_themeImageBusy || widget.onThemeBackgroundImageChanged == null) return;
    setState(() => _themeImageBusy = true);
    try {
      final picked = await ImagePicker().pickImage(
        source: ImageSource.gallery,
        imageQuality: 92,
      );
      if (picked == null) return;

      final appDir = await getApplicationDocumentsDirectory();
      final dir = Directory('${appDir.path}/theme_backgrounds');
      if (!await dir.exists()) {
        await dir.create(recursive: true);
      }

      final ext = _extOf(picked.path);
      final outPath =
          '${dir.path}/bg_${DateTime.now().millisecondsSinceEpoch}$ext';
      await File(picked.path).copy(outPath);

      await Future<void>.sync(
        () => widget.onThemeBackgroundImageChanged?.call(outPath),
      );

      if (!mounted) return;
      _toast(
        tr(context, en: 'Theme background updated', zh: '主题背景已更新'),
        icon: Icons.image_rounded,
      );
      setState(() {});
    } catch (e) {
      if (!mounted) return;
      _toast(
        '${tr(context, en: 'Image set failed', zh: '图片设置失败')}: $e',
        icon: Icons.error_outline,
      );
    } finally {
      if (mounted) {
        setState(() => _themeImageBusy = false);
      }
    }
  }

  Future<void> _clearThemeBackgroundImage() async {
    if (widget.onThemeBackgroundImageChanged == null) return;
    await Future<void>.sync(
      () => widget.onThemeBackgroundImageChanged?.call(null),
    );
    if (!mounted) return;
    _toast(
      tr(context, en: 'Theme background cleared', zh: '主题背景已清除'),
      icon: Icons.layers_clear_rounded,
    );
    setState(() {});
  }

  @override
  void dispose() {
    _debounce?.cancel();
    _lowBalanceCtrl.removeListener(_onAmountChanged);
    _lowBalanceCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final svc = ImportExportService(widget.db);

    final langCode = Localizations.localeOf(context).languageCode.toLowerCase();
    final isZh = langCode.startsWith('zh');

    return Scaffold(
      appBar: AppBar(
        title: Text(tr(context, en: 'Settings', zh: '设置')),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.all(16),
              children: [
                /// ===============================
                /// Language (Switch)
                /// ===============================
                if (widget.onToggleLocale != null)
                  Card(
                    child: SwitchListTile(
                      secondary: const Icon(Icons.language),
                      title: Text(tr(context, en: 'Language', zh: '语言')),
                      subtitle: Text(isZh ? '中文' : 'English'),
                      value: isZh,
                      onChanged: (_) {
                        widget.onToggleLocale?.call();
                        setState(() {});
                      },
                    ),
                  ),

                const SizedBox(height: 16),

                /// ===============================
                /// Theme style + custom background
                /// ===============================
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          tr(context, en: 'Theme', zh: '主题'),
                          style: const TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          tr(
                            context,
                            en: 'Switch visual style and set a custom background image.',
                            zh: '切换视觉风格并设置自定义背景图片。',
                          ),
                          style: TextStyle(
                            color: Theme.of(
                              context,
                            ).colorScheme.onSurfaceVariant,
                          ),
                        ),
                        const SizedBox(height: 16),
                        SwitchListTile(
                          contentPadding: EdgeInsets.zero,
                          secondary: Icon(
                            widget.isDarkMode
                                ? Icons.dark_mode_rounded
                                : Icons.light_mode_rounded,
                          ),
                          title: Text(tr(context, en: 'Dark mode', zh: '深色模式')),
                          subtitle: Text(
                            widget.isDarkMode
                                ? tr(context, en: 'Enabled', zh: '已开启')
                                : tr(context, en: 'Disabled', zh: '已关闭'),
                          ),
                          value: widget.isDarkMode,
                          onChanged: widget.onToggleThemeMode == null
                              ? null
                              : (_) {
                                  widget.onToggleThemeMode?.call();
                                  setState(() {});
                                },
                        ),
                        const SizedBox(height: 8),
                        DropdownButtonFormField<AppThemeStyle>(
                          value: widget.activeThemeStyle,
                          decoration: InputDecoration(
                            labelText: tr(
                              context,
                              en: 'Theme style',
                              zh: '主题风格',
                            ),
                            prefixIcon: const Icon(Icons.palette_rounded),
                          ),
                          items: AppThemeStyle.values
                              .map(
                                (style) => DropdownMenuItem<AppThemeStyle>(
                                  value: style,
                                  child: Text(themeStyleLabel(context, style)),
                                ),
                              )
                              .toList(growable: false),
                          onChanged: (v) {
                            if (v == null) return;
                            widget.onThemeStyleChanged?.call(v);
                            setState(() {});
                          },
                        ),
                        const SizedBox(height: 12),
                        Text(
                          tr(
                            context,
                            en: 'Custom background image',
                            zh: '自定义背景图片',
                          ),
                          style: const TextStyle(fontWeight: FontWeight.w700),
                        ),
                        const SizedBox(height: 8),
                        Container(
                          height: 132,
                          width: double.infinity,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(16),
                            border: Border.all(
                              color: Theme.of(
                                context,
                              ).colorScheme.outlineVariant,
                            ),
                            color: Theme.of(
                              context,
                            ).colorScheme.surfaceContainerHighest,
                          ),
                          clipBehavior: Clip.antiAlias,
                          child: Builder(
                            builder: (_) {
                              final p = widget.themeBackgroundImagePath;
                              if (p == null ||
                                  p.isEmpty ||
                                  !File(p).existsSync()) {
                                return Center(
                                  child: Text(
                                    tr(
                                      context,
                                      en: 'No custom image selected',
                                      zh: '尚未选择自定义图片',
                                    ),
                                    style: TextStyle(
                                      color: Theme.of(
                                        context,
                                      ).colorScheme.onSurfaceVariant,
                                    ),
                                  ),
                                );
                              }
                              return Image.file(File(p), fit: BoxFit.cover);
                            },
                          ),
                        ),
                        const SizedBox(height: 10),
                        Row(
                          children: [
                            Expanded(
                              child: FilledButton.icon(
                                onPressed: _themeImageBusy
                                    ? null
                                    : _pickThemeBackgroundImage,
                                icon: _themeImageBusy
                                    ? const SizedBox(
                                        width: 16,
                                        height: 16,
                                        child: CircularProgressIndicator(
                                          strokeWidth: 2,
                                        ),
                                      )
                                    : const Icon(Icons.photo_library_rounded),
                                label: Text(
                                  tr(context, en: 'Choose image', zh: '选择图片'),
                                ),
                              ),
                            ),
                            const SizedBox(width: 10),
                            OutlinedButton.icon(
                              onPressed:
                                  (widget.themeBackgroundImagePath == null ||
                                      widget.themeBackgroundImagePath!.isEmpty)
                                  ? null
                                  : _clearThemeBackgroundImage,
                              icon: const Icon(Icons.delete_outline_rounded),
                              label: Text(tr(context, en: 'Clear', zh: '清除')),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),

                const SizedBox(height: 16),

                /// ===============================
                /// Low Balance Reminder (Switch + Expand input + Auto-save)
                /// ===============================
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(8),
                    child: Column(
                      children: [
                        SwitchListTile(
                          secondary: const Icon(Icons.notifications_active),
                          title: Text(
                            tr(
                              context,
                              en: 'Low Balance Reminder',
                              zh: '余额不足提醒',
                            ),
                          ),
                          subtitle: Text(
                            tr(
                              context,
                              en: 'Auto-save amount when enabled',
                              zh: '开启后自动保存提醒金额',
                            ),
                          ),
                          value: _lowBalanceReminderOn,
                          onChanged: (v) async {
                            setState(() => _lowBalanceReminderOn = v);

                            if (v) {
                              await _turnOnAndAutoSave();
                            } else {
                              await _turnOffAndClear();
                            }
                          },
                        ),

                        AnimatedSize(
                          duration: const Duration(milliseconds: 200),
                          curve: Curves.easeInOut,
                          child: _lowBalanceReminderOn
                              ? Padding(
                                  padding: const EdgeInsets.fromLTRB(
                                    16,
                                    0,
                                    16,
                                    12,
                                  ),
                                  child: TextField(
                                    controller: _lowBalanceCtrl,
                                    keyboardType:
                                        const TextInputType.numberWithOptions(
                                          decimal: true,
                                        ),
                                    decoration: InputDecoration(
                                      labelText: tr(
                                        context,
                                        en: 'Reminder Amount',
                                        zh: '提醒金额',
                                      ),
                                      prefixText: '\$ ',
                                      hintText: tr(
                                        context,
                                        en: 'e.g. 100',
                                        zh: '例如 100',
                                      ),
                                      helperText: tr(
                                        context,
                                        en: 'Saved automatically while typing',
                                        zh: '输入时会自动保存',
                                      ),
                                    ),
                                  ),
                                )
                              : const SizedBox.shrink(),
                        ),
                      ],
                    ),
                  ),
                ),

                const SizedBox(height: 16),

                /// ===============================
                /// Home Quick Actions (4 buttons on Home: Search/Add fixed; 2 customizable)
                /// ===============================
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          tr(context, en: 'Home Quick Actions', zh: '主页快捷按键'),
                          style: const TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          tr(
                            context,
                            en: 'Search and Add are fixed on the home page. Customize the other two buttons here.',
                            zh: '主页固定显示“搜索”“新增”，下面可自定义另外两个按键。',
                          ),
                          style: TextStyle(
                            color: Theme.of(
                              context,
                            ).colorScheme.onSurfaceVariant,
                          ),
                        ),
                        const SizedBox(height: 16),

                        DropdownButtonFormField<QuickActionKey>(
                          value: _slot3,
                          decoration: InputDecoration(
                            labelText: tr(context, en: 'Button 3', zh: '按键 3'),
                            prefixIcon: Icon(qaIcon(_slot3)),
                          ),
                          items: QuickActionKey.values.map((k) {
                            return DropdownMenuItem(
                              value: k,
                              child: Text(qaLabel(context, k)),
                            );
                          }).toList(),
                          onChanged: (v) async {
                            if (v == null) return;
                            setState(() => _slot3 = v);
                            if (_slot3 == _slot4) {
                              final fb = QuickActionKey.values.firstWhere(
                                (e) => e != _slot3,
                              );
                              setState(() => _slot4 = fb);
                            }
                            await _saveQuickActions();
                          },
                        ),

                        const SizedBox(height: 12),

                        DropdownButtonFormField<QuickActionKey>(
                          value: _slot4,
                          decoration: InputDecoration(
                            labelText: tr(context, en: 'Button 4', zh: '按键 4'),
                            prefixIcon: Icon(qaIcon(_slot4)),
                          ),
                          items: QuickActionKey.values.map((k) {
                            return DropdownMenuItem(
                              value: k,
                              child: Text(qaLabel(context, k)),
                            );
                          }).toList(),
                          onChanged: (v) async {
                            if (v == null) return;
                            setState(() => _slot4 = v);
                            if (_slot3 == _slot4) {
                              final fb = QuickActionKey.values.firstWhere(
                                (e) => e != _slot4,
                              );
                              setState(() => _slot3 = fb);
                            }
                            await _saveQuickActions();
                          },
                        ),

                        const SizedBox(height: 12),
                        OutlinedButton.icon(
                          icon: const Icon(Icons.restart_alt),
                          label: Text(
                            tr(
                              context,
                              en: 'Reset to default (Stats + History)',
                              zh: '恢复默认（统计 + 历史）',
                            ),
                          ),
                          onPressed: () async {
                            setState(() {
                              _slot3 = QuickActionKey.stats;
                              _slot4 = QuickActionKey.history;
                            });
                            await _saveQuickActions();
                          },
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 16),

                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: AnimatedBuilder(
                      animation: PetConfig.I,
                      builder: (context, _) {
                        final cfg = PetConfig.I;

                        return Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              tr(context, en: 'Pet Assistant', zh: '宠物助手'),
                              style: const TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.w800,
                              ),
                            ),
                            const SizedBox(height: 8),
                            Text(
                              tr(
                                context,
                                en: 'Enable the draggable pet overlay, tune how often it speaks, and change its look.',
                                zh: '启用可拖动宠物浮窗，调整发言频率并切换外观素材。',
                              ),
                              style: TextStyle(
                                color: Theme.of(
                                  context,
                                ).colorScheme.onSurfaceVariant,
                              ),
                            ),
                            const SizedBox(height: 16),

                            SwitchListTile(
                              contentPadding: EdgeInsets.zero,
                              title: Text(
                                tr(context, en: 'Enable pet', zh: '启用宠物'),
                              ),
                              subtitle: Text(
                                tr(
                                  context,
                                  en: 'Show the pet overlay in app',
                                  zh: '在应用内显示宠物浮窗',
                                ),
                              ),
                              value: cfg.enabled,
                              onChanged: (v) => cfg.setEnabled(v),
                            ),

                            const SizedBox(height: 8),

                            DropdownButtonFormField<PetFrequency>(
                              value: cfg.frequency,
                              decoration: InputDecoration(
                                labelText: tr(
                                  context,
                                  en: 'Speak frequency',
                                  zh: '发言频率',
                                ),
                                prefixIcon: const Icon(
                                  Icons.chat_bubble_outline,
                                ),
                              ),
                              items: [
                                DropdownMenuItem(
                                  value: PetFrequency.low,
                                  child: Text(
                                    tr(context, en: 'Low', zh: '低（更安静）'),
                                  ),
                                ),
                                DropdownMenuItem(
                                  value: PetFrequency.normal,
                                  child: Text(
                                    tr(context, en: 'Normal', zh: '中（推荐）'),
                                  ),
                                ),
                                DropdownMenuItem(
                                  value: PetFrequency.high,
                                  child: Text(
                                    tr(context, en: 'High', zh: '高（更活跃）'),
                                  ),
                                ),
                              ],
                              onChanged: cfg.enabled
                                  ? (v) async {
                                      if (v == null) return;
                                      await cfg.setFrequency(v);
                                    }
                                  : null,
                            ),

                            const SizedBox(height: 12),

                            ListTile(
                              contentPadding: EdgeInsets.zero,
                              leading: const Icon(Icons.zoom_out_map_rounded),
                              title: Text(
                                tr(context, en: 'Pet size', zh: '宠物大小'),
                              ),
                              subtitle: Text(
                                tr(
                                  context,
                                  en: 'Current: ${cfg.sizeScale.toStringAsFixed(2)}x',
                                  zh: '当前：${cfg.sizeScale.toStringAsFixed(2)}x',
                                ),
                              ),
                            ),
                            Slider(
                              min: 0,
                              max: 4,
                              divisions: 4,
                              value: cfg.sizeLevel.toDouble(),
                              label: '${cfg.sizeScale.toStringAsFixed(2)}x',
                              onChanged: cfg.enabled
                                  ? (v) async {
                                      await cfg.setSizeLevel(v.round());
                                    }
                                  : null,
                            ),

                            const SizedBox(height: 12),

                            DropdownButtonFormField<String>(
                              value: cfg.skinId,
                              decoration: InputDecoration(
                                labelText: tr(
                                  context,
                                  en: 'Appearance',
                                  zh: '宠物外观',
                                ),
                                prefixIcon: const Icon(Icons.pets_outlined),
                              ),
                              items: PetConfig.skins.map((s) {
                                return DropdownMenuItem(
                                  value: s.id,
                                  child: Text(s.name),
                                );
                              }).toList(),
                              onChanged: cfg.enabled
                                  ? (id) async {
                                      if (id == null) return;
                                      await cfg.setSkin(id);
                                    }
                                  : null,
                            ),
                          ],
                        );
                      },
                    ),
                  ),
                ),

                const SizedBox(height: 24),

                /// ===============================
                /// Import & Export
                /// ===============================
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          tr(context, en: 'Import & Export', zh: '导入与导出'),
                          style: const TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          tr(
                            context,
                            en: 'Backup and restore accounts, categories and history.',
                            zh: '备份并恢复账户、分类与历史记录。',
                          ),
                          style: TextStyle(
                            color: Theme.of(
                              context,
                            ).colorScheme.onSurfaceVariant,
                          ),
                        ),
                        const SizedBox(height: 16),

                        FilledButton.icon(
                          icon: const Icon(Icons.upload_file),
                          label: Text(
                            tr(
                              context,
                              en: 'Export Backup (JSON)',
                              zh: '导出备份（JSON）',
                            ),
                          ),
                          onPressed: () async {
                            try {
                              final f = await svc.exportFullBackupJson();
                              await svc.shareFile(f);
                              if (!mounted) return;
                              _toast(
                                tr(context, en: 'Backup exported', zh: '备份已导出'),
                                icon: Icons.check_circle_outline,
                              );
                            } catch (e) {
                              if (!mounted) return;
                              _toast(
                                '${tr(context, en: 'Export failed', zh: '导出失败')}: $e',
                                icon: Icons.error_outline,
                              );
                            }
                          },
                        ),

                        const SizedBox(height: 12),

                        OutlinedButton.icon(
                          icon: const Icon(Icons.download),
                          label: Text(
                            tr(
                              context,
                              en: 'Import (Append Only)',
                              zh: '导入（仅追加）',
                            ),
                          ),
                          onPressed: () async {
                            try {
                              final picked = await svc.pickBackupJson();
                              if (picked == null) return;

                              final ok =
                                  await showDialog<bool>(
                                    context: context,
                                    builder: (ctx) => AlertDialog(
                                      title: Text(
                                        tr(
                                          context,
                                          en: 'Import (Append)',
                                          zh: '导入（仅追加）',
                                        ),
                                      ),
                                      content: Text(
                                        tr(
                                          context,
                                          en: 'This will only add missing data and will NOT delete existing records.',
                                          zh: '此操作只会追加缺失数据，不会删除现有记录。',
                                        ),
                                      ),
                                      actions: [
                                        TextButton(
                                          onPressed: () =>
                                              Navigator.pop(ctx, false),
                                          child: Text(
                                            tr(context, en: 'Cancel', zh: '取消'),
                                          ),
                                        ),
                                        FilledButton(
                                          onPressed: () =>
                                              Navigator.pop(ctx, true),
                                          child: Text(
                                            tr(
                                              context,
                                              en: 'Import',
                                              zh: '开始导入',
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ) ??
                                  false;

                              if (!ok) return;

                              final r = await svc.importAppend(picked.data);
                              if (!mounted) return;

                              _toast(
                                tr(
                                  context,
                                  en: 'Imported ${r.insertedTransactions}, Skipped ${r.skippedTransactions}',
                                  zh: '已导入 ${r.insertedTransactions} 条，跳过 ${r.skippedTransactions} 条',
                                ),
                                icon: Icons.check_circle_outline,
                              );

                              // Notify home page to refresh.
                              Navigator.pop(context, true);
                            } catch (e) {
                              if (!mounted) return;
                              _toast(
                                '${tr(context, en: 'Import failed', zh: '导入失败')}: $e',
                                icon: Icons.error_outline,
                              );
                            }
                          },
                        ),

                        const SizedBox(height: 12),

                        OutlinedButton.icon(
                          icon: const Icon(Icons.warning_amber_rounded),
                          label: Text(
                            tr(
                              context,
                              en: 'Wipe & Restore from Backup',
                              zh: '清空数据库后恢复',
                            ),
                          ),
                          onPressed: () async {
                            try {
                              final picked = await svc.pickBackupJson();
                              if (picked == null) return;

                              final ok1 =
                                  await showDialog<bool>(
                                    context: context,
                                    builder: (ctx) => AlertDialog(
                                      title: Text(
                                        tr(context, en: 'Danger', zh: '危险操作'),
                                      ),
                                      content: Text(
                                        tr(
                                          context,
                                          en: 'This will DELETE all local data and restore from the backup.',
                                          zh: '此操作会删除本地所有数据，然后从备份恢复。',
                                        ),
                                      ),
                                      actions: [
                                        TextButton(
                                          onPressed: () =>
                                              Navigator.pop(ctx, false),
                                          child: Text(
                                            tr(context, en: 'Cancel', zh: '取消'),
                                          ),
                                        ),
                                        FilledButton(
                                          onPressed: () =>
                                              Navigator.pop(ctx, true),
                                          child: Text(
                                            tr(
                                              context,
                                              en: 'Continue',
                                              zh: '继续',
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ) ??
                                  false;

                              if (!ok1) return;

                              final ok2 =
                                  await showDialog<bool>(
                                    context: context,
                                    builder: (ctx) => AlertDialog(
                                      title: Text(
                                        tr(
                                          context,
                                          en: 'Final Confirmation',
                                          zh: '最终确认',
                                        ),
                                      ),
                                      content: Text(
                                        tr(
                                          context,
                                          en: 'Are you absolutely sure?',
                                          zh: '你确定要执行吗？',
                                        ),
                                      ),
                                      actions: [
                                        TextButton(
                                          onPressed: () =>
                                              Navigator.pop(ctx, false),
                                          child: Text(
                                            tr(context, en: 'Cancel', zh: '取消'),
                                          ),
                                        ),
                                        FilledButton(
                                          onPressed: () =>
                                              Navigator.pop(ctx, true),
                                          child: Text(
                                            tr(
                                              context,
                                              en: 'Wipe & Restore',
                                              zh: '清空并恢复',
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ) ??
                                  false;

                              if (!ok2) return;

                              final r = await svc.restoreAfterWipe(picked.data);
                              if (!mounted) return;

                              _toast(
                                tr(
                                  context,
                                  en: 'Restored ${r.insertedTransactions} transactions',
                                  zh: '已恢复 ${r.insertedTransactions} 条交易',
                                ),
                                icon: Icons.check_circle_outline,
                              );

                              // Notify home page to refresh.
                              Navigator.pop(context, true);
                            } catch (e) {
                              if (!mounted) return;
                              _toast(
                                '${tr(context, en: 'Restore failed', zh: '恢复失败')}: $e',
                                icon: Icons.error_outline,
                              );
                            }
                          },
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
    );
  }
}
