import 'package:flutter/material.dart';

class CoachOverlay extends StatelessWidget {
  final Rect? targetRect;
  final String title;
  final String message;
  final int index;
  final int total;
  final bool isLastStep;
  final VoidCallback onSkip;
  final VoidCallback onNext;
  final VoidCallback? onPrevious;
  final String backLabel;
  final String skipLabel;
  final String nextLabel;
  final String doneLabel;

  const CoachOverlay({
    super.key,
    required this.targetRect,
    required this.title,
    required this.message,
    required this.index,
    required this.total,
    required this.isLastStep,
    required this.onSkip,
    required this.onNext,
    this.onPrevious,
    required this.backLabel,
    required this.skipLabel,
    required this.nextLabel,
    required this.doneLabel,
  });

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final rect = targetRect;
    final adaptiveInset = rect == null
        ? 0.0
        : (rect.shortestSide * 0.18).clamp(6.0, 14.0);
    final highlightRect = rect?.inflate(adaptiveInset);
    const highlightRadius = 16.0;
    final innerFogAlpha = highlightRect == null
        ? 0.0
        : (highlightRect.shortestSide / 500).clamp(0.10, 0.20);

    return Material(
      color: Colors.transparent,
      child: Stack(
        children: [
          Positioned.fill(
            child: IgnorePointer(
              child: CustomPaint(
                painter: _ScrimWithHolePainter(
                  holeRect: highlightRect,
                  holeRadius: highlightRadius,
                  scrimColor: Colors.black.withValues(alpha: 0.62),
                ),
              ),
            ),
          ),
          if (highlightRect != null)
            Positioned.fromRect(
              rect: highlightRect,
              child: GestureDetector(
                behavior: HitTestBehavior.opaque,
                onTap: onNext,
                child: DecoratedBox(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(highlightRadius),
                    border: Border.all(color: cs.primary, width: 2.4),
                    boxShadow: [
                      BoxShadow(
                        color: cs.primary.withValues(alpha: 0.35),
                        blurRadius: 18,
                        spreadRadius: 2,
                      ),
                    ],
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(highlightRadius),
                    child: DecoratedBox(
                      decoration: BoxDecoration(
                        gradient: RadialGradient(
                          center: Alignment.center,
                          radius: 1.0,
                          colors: [
                            Colors.transparent,
                            Colors.transparent,
                            Colors.black.withValues(alpha: innerFogAlpha),
                          ],
                          stops: const [0.70, 0.86, 1.0],
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          Align(
            alignment: Alignment.bottomCenter,
            child: SafeArea(
              top: false,
              minimum: const EdgeInsets.fromLTRB(14, 14, 14, 14),
              child: DecoratedBox(
                decoration: BoxDecoration(
                  color: cs.surface,
                  borderRadius: BorderRadius.circular(18),
                  border: Border.all(color: cs.outlineVariant),
                ),
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(14, 14, 14, 10),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        title,
                        style: Theme.of(context).textTheme.titleMedium
                            ?.copyWith(fontWeight: FontWeight.w800),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        message,
                        style: Theme.of(context).textTheme.bodyMedium,
                      ),
                      const SizedBox(height: 12),
                      Row(
                        children: [
                          Text(
                            '$index / $total',
                            style: Theme.of(context).textTheme.labelMedium
                                ?.copyWith(color: cs.onSurfaceVariant),
                          ),
                          const Spacer(),
                          if (onPrevious != null)
                            TextButton(
                              onPressed: onPrevious,
                              child: Text(backLabel),
                            ),
                          TextButton(
                            onPressed: onSkip,
                            child: Text(skipLabel),
                          ),
                          const SizedBox(width: 8),
                          FilledButton(
                            onPressed: onNext,
                            child: Text(isLastStep ? doneLabel : nextLabel),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _ScrimWithHolePainter extends CustomPainter {
  final Rect? holeRect;
  final double holeRadius;
  final Color scrimColor;

  const _ScrimWithHolePainter({
    required this.holeRect,
    required this.holeRadius,
    required this.scrimColor,
  });

  @override
  void paint(Canvas canvas, Size size) {
    if (holeRect == null) {
      canvas.drawRect(
        Offset.zero & size,
        Paint()
          ..color = scrimColor
          ..isAntiAlias = true,
      );
      return;
    }

    final scrimPath = Path()
      ..fillType = PathFillType.evenOdd
      ..addRect(Offset.zero & size)
      ..addRRect(
        RRect.fromRectAndRadius(holeRect!, Radius.circular(holeRadius)),
      );

    canvas.drawPath(
      scrimPath,
      Paint()
        ..color = scrimColor
        ..isAntiAlias = true,
    );
  }

  @override
  bool shouldRepaint(covariant _ScrimWithHolePainter oldDelegate) {
    return oldDelegate.holeRect != holeRect ||
        oldDelegate.holeRadius != holeRadius ||
        oldDelegate.scrimColor != scrimColor;
  }
}
