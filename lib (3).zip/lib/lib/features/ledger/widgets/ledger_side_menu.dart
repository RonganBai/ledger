import 'package:flutter/material.dart';

import '../../../l10n/tr.dart';

class LedgerSideMenu extends StatelessWidget {
  final WidgetBuilder statsPageBuilder;
  final VoidCallback? onOpenStats;
  final VoidCallback onSwitchAccount;
  final VoidCallback onManageAccounts;
  final VoidCallback onOpenHistory;
  final VoidCallback onOpenRecurring;
  final VoidCallback onOpenCategories;
  final VoidCallback onOpenSettings;
  final VoidCallback? onReplayTutorial;
  final VoidCallback onToggleTheme;
  final bool isDarkMode;

  const LedgerSideMenu({
    super.key,
    required this.statsPageBuilder,
    this.onOpenStats,
    required this.onSwitchAccount,
    required this.onManageAccounts,
    required this.onOpenHistory,
    required this.onOpenRecurring,
    required this.onOpenCategories,
    required this.onOpenSettings,
    this.onReplayTutorial,
    required this.onToggleTheme,
    required this.isDarkMode,
  });

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;

    Widget groupTitle(String text) => Padding(
      padding: const EdgeInsets.fromLTRB(18, 16, 18, 10),
      child: Text(
        text,
        style: Theme.of(context).textTheme.labelLarge?.copyWith(
          color: cs.onSurfaceVariant,
          fontWeight: FontWeight.w700,
        ),
      ),
    );

    Widget tile({
      required IconData icon,
      required String title,
      required VoidCallback onTap,
    }) {
      return InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          child: Row(
            children: [
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  color: cs.surfaceContainerHighest,
                  borderRadius: BorderRadius.circular(14),
                ),
                alignment: Alignment.center,
                child: Icon(icon, size: 22, color: cs.onSurface),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  title,
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
              Icon(Icons.chevron_right_rounded, color: cs.onSurfaceVariant),
            ],
          ),
        ),
      );
    }

    Widget card({required List<Widget> children}) {
      return Padding(
        padding: const EdgeInsets.symmetric(horizontal: 14),
        child: Material(
          color: cs.surface,
          elevation: 0,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(18),
            side: BorderSide(color: cs.outlineVariant),
          ),
          child: Column(
            children: [
              for (int i = 0; i < children.length; i++) ...[
                children[i],
                if (i != children.length - 1)
                  Divider(
                    height: 1,
                    thickness: 1,
                    color: cs.outlineVariant.withValues(alpha: 130),
                  ),
              ],
            ],
          ),
        ),
      );
    }

    return LayoutBuilder(
      builder: (context, constraints) {
        return SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          padding: const EdgeInsets.only(top: 8, bottom: 14),
          child: ConstrainedBox(
            constraints: BoxConstraints(minHeight: constraints.maxHeight - 22),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                groupTitle(tr(context, en: 'Accounts', zh: '账户')),
                card(
                  children: [
                    tile(
                      icon: Icons.swap_horiz_rounded,
                      title: tr(context, en: 'Switch Account', zh: '切换账户'),
                      onTap: onSwitchAccount,
                    ),
                    tile(
                      icon: Icons.account_balance_wallet_rounded,
                      title: tr(context, en: 'Manage Accounts', zh: '账户管理'),
                      onTap: onManageAccounts,
                    ),
                  ],
                ),
                groupTitle(tr(context, en: 'Navigate', zh: '导航')),
                card(
                  children: [
                    tile(
                      icon: Icons.analytics_rounded,
                      title: tr(context, en: 'Stats', zh: '统计'),
                      onTap: () {
                        if (onOpenStats != null) {
                          onOpenStats!.call();
                          return;
                        }
                        Navigator.of(context).maybePop();
                        Navigator.of(
                          context,
                        ).push(MaterialPageRoute(builder: statsPageBuilder));
                      },
                    ),
                    tile(
                      icon: Icons.calendar_month_rounded,
                      title: tr(context, en: 'History', zh: '历史'),
                      onTap: onOpenHistory,
                    ),
                    tile(
                      icon: Icons.repeat_rounded,
                      title: tr(context, en: 'Recurring', zh: '周期交易'),
                      onTap: onOpenRecurring,
                    ),
                    tile(
                      icon: Icons.category_outlined,
                      title: tr(context, en: 'Categories', zh: '分类管理'),
                      onTap: onOpenCategories,
                    ),
                  ],
                ),
                groupTitle(tr(context, en: 'Preferences', zh: '偏好')),
                card(
                  children: [
                    if (onReplayTutorial != null)
                      tile(
                        icon: Icons.school_rounded,
                        title: tr(
                          context,
                          en: 'Replay Tutorial',
                          zh: '重新播放新手教程',
                        ),
                        onTap: onReplayTutorial!,
                      ),
                    tile(
                      icon: Icons.settings_rounded,
                      title: tr(context, en: 'Settings', zh: '设置'),
                      onTap: onOpenSettings,
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                Center(
                  child: Semantics(
                    label: tr(context, en: 'Toggle theme mode', zh: '切换主题模式'),
                    child: Material(
                      color: cs.primary,
                      shape: const CircleBorder(),
                      child: InkWell(
                        customBorder: const CircleBorder(),
                        onTap: onToggleTheme,
                        child: SizedBox(
                          width: 54,
                          height: 54,
                          child: Icon(
                            isDarkMode
                                ? Icons.wb_sunny_rounded
                                : Icons.dark_mode_rounded,
                            color: cs.onPrimary,
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 8),
                Padding(
                  padding: const EdgeInsets.fromLTRB(14, 0, 14, 0),
                  child: Text(
                    tr(context, en: 'Swipe left to close', zh: '左滑关闭菜单'),
                    textAlign: TextAlign.center,
                    style: Theme.of(context).textTheme.labelMedium?.copyWith(
                      color: cs.onSurfaceVariant,
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
