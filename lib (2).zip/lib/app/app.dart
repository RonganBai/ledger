import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../data/db/app_database.dart';
import '../features/ledger/ledger_home.dart';
import '../ui/pet/pet_config.dart';
import '../ui/pet/pet_overlay.dart';
import 'theme.dart';

class MyApp extends StatefulWidget {
  final AppDatabase db;

  const MyApp({super.key, required this.db});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  static const _kDarkModePref = 'app_dark_mode';
  Locale _locale = const Locale('zh');
  bool _darkMode = false;

  @override
  void initState() {
    super.initState();
    PetConfig.I.load();
    _loadThemeMode();
  }

  void _toggleLocale() {
    setState(() {
      _locale = _locale.languageCode == 'zh'
          ? const Locale('en')
          : const Locale('zh');
    });
  }

  Future<void> _loadThemeMode() async {
    final prefs = await SharedPreferences.getInstance();
    final dark = prefs.getBool(_kDarkModePref) ?? false;
    if (!mounted) return;
    setState(() => _darkMode = dark);
  }

  Future<void> _toggleTheme() async {
    final next = !_darkMode;
    setState(() => _darkMode = next);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_kDarkModePref, next);
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      builder: (context, child) {
        return Listener(
          behavior: HitTestBehavior.translucent,
          onPointerDown: (_) => FocusManager.instance.primaryFocus?.unfocus(),
          child: Stack(
            children: [
              if (child != null) child,
              AnimatedBuilder(
                animation: PetConfig.I,
                builder: (_, __) => PetConfig.I.enabled
                    ? const PetOverlay()
                    : const SizedBox.shrink(),
              ),
            ],
          ),
        );
      },
      debugShowCheckedModeBanner: false,
      title: 'Ledger',
      locale: _locale,
      supportedLocales: const [Locale('en'), Locale('zh')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      theme: buildLightTheme(),
      darkTheme: buildDarkTheme(),
      themeMode: _darkMode ? ThemeMode.dark : ThemeMode.light,
      home: LedgerHome(
        db: widget.db,
        onToggleLocale: _toggleLocale,
        onToggleTheme: _toggleTheme,
        isDarkMode: _darkMode,
      ),
    );
  }
}
