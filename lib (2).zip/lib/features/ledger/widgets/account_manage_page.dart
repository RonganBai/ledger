﻿import 'package:drift/drift.dart' as d;
import 'package:flutter/material.dart';

import '../../../data/db/app_database.dart';
import '../../../l10n/tr.dart';

class AccountManagePage extends StatelessWidget {
  final AppDatabase db;

  const AccountManagePage({super.key, required this.db});

  Future<void> _upsertAccount(BuildContext context, {Account? editing}) async {
    final result = await showDialog<_AccountFormResult>(
      context: context,
      builder: (_) => _AccountEditDialog(editing: editing),
    );
    if (result == null) return;

    if (editing == null) {
      await db.into(db.accounts).insert(
            AccountsCompanion.insert(
              name: result.name,
              type: d.Value(result.type),
              currency: d.Value(result.currency),
            ),
          );
      return;
    }

    await (db.update(db.accounts)..where((a) => a.id.equals(editing.id))).write(
      AccountsCompanion(
        name: d.Value(result.name),
        type: d.Value(result.type),
        currency: d.Value(result.currency),
      ),
    );
  }

  Future<void> _deleteAccount(BuildContext context, Account account) async {
    final activeCount = await (db.selectOnly(db.accounts)
          ..addColumns([db.accounts.id.count()])
          ..where(db.accounts.isActive.equals(true)))
        .getSingle();
    final count = activeCount.read(db.accounts.id.count()) ?? 0;
    if (count <= 1) {
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(tr(context, en: 'At least one account is required.', zh: '至少保留一个账户。'))),
      );
      return;
    }

    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(tr(context, en: 'Delete account?', zh: '删除账户？')),
        content: Text(
          tr(
            context,
            en: 'Delete account "${account.name}" and all its transactions?',
            zh: '删除账户“${account.name}”及其所有账单？',
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: Text(tr(context, en: 'Cancel', zh: '取消'))),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: Text(tr(context, en: 'Delete', zh: '删除'))),
        ],
      ),
    );

    if (ok != true) return;

    await db.transaction(() async {
      await (db.delete(db.transactions)..where((t) => t.accountId.equals(account.id))).go();
      await (db.delete(db.accounts)..where((a) => a.id.equals(account.id))).go();
    });
  }

  @override
  Widget build(BuildContext context) {
    final stream = (db.select(db.accounts)
          ..where((a) => a.isActive.equals(true))
          ..orderBy([
            (a) => d.OrderingTerm(expression: a.sortOrder),
            (a) => d.OrderingTerm(expression: a.id),
          ]))
        .watch();

    return Scaffold(
      appBar: AppBar(title: Text(tr(context, en: 'Manage Accounts', zh: '账户管理'))),
      body: StreamBuilder<List<Account>>(
        stream: stream,
        builder: (context, snapshot) {
          final rows = snapshot.data ?? const <Account>[];
          if (rows.isEmpty) {
            return Center(
              child: Text(tr(context, en: 'No accounts', zh: '暂无账户')),
            );
          }

          return ListView.separated(
            padding: const EdgeInsets.fromLTRB(12, 12, 12, 88),
            itemCount: rows.length,
            separatorBuilder: (_, __) => const SizedBox(height: 8),
            itemBuilder: (_, i) {
              final a = rows[i];
              return Card(
                child: ListTile(
                  title: Text(a.name, style: const TextStyle(fontWeight: FontWeight.w700)),
                  subtitle: Text('${a.type.toUpperCase()}  |  ${a.currency.toUpperCase()}'),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      IconButton(
                        tooltip: tr(context, en: 'Edit', zh: '编辑'),
                        onPressed: () => _upsertAccount(context, editing: a),
                        icon: const Icon(Icons.edit_rounded),
                      ),
                      IconButton(
                        tooltip: tr(context, en: 'Delete', zh: '删除'),
                        onPressed: () => _deleteAccount(context, a),
                        icon: const Icon(Icons.delete_outline_rounded),
                      ),
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _upsertAccount(context),
        icon: const Icon(Icons.add_rounded),
        label: Text(tr(context, en: 'Add Account', zh: '新增账户')),
      ),
    );
  }
}

class _AccountEditDialog extends StatefulWidget {
  final Account? editing;
  const _AccountEditDialog({this.editing});

  @override
  State<_AccountEditDialog> createState() => _AccountEditDialogState();
}

class _AccountEditDialogState extends State<_AccountEditDialog> {
  late final TextEditingController _nameCtrl;
  late String _type;
  late String _currency;

  static const _types = <String>['cash', 'bank', 'card', 'paypal', 'other'];
  static const _currencies = <String>['USD', 'CNY', 'HKD', 'EUR', 'JPY', 'KRW', 'GBP'];

  @override
  void initState() {
    super.initState();
    final e = widget.editing;
    _nameCtrl = TextEditingController(text: e?.name ?? '');
    _type = (e?.type ?? 'cash').toLowerCase();
    _currency = (e?.currency ?? 'USD').toUpperCase();
  }

  @override
  void dispose() {
    _nameCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(widget.editing == null ? tr(context, en: 'Add Account', zh: '新增账户') : tr(context, en: 'Edit Account', zh: '编辑账户')),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: _nameCtrl,
              decoration: InputDecoration(labelText: tr(context, en: 'Account name', zh: '账户名称')),
            ),
            const SizedBox(height: 12),
            DropdownButtonFormField<String>(
              initialValue: _type,
              decoration: InputDecoration(labelText: tr(context, en: 'Type', zh: '类型')),
              items: _types
                  .map((e) => DropdownMenuItem<String>(value: e, child: Text(e.toUpperCase())))
                  .toList(growable: false),
              onChanged: (v) {
                if (v == null) return;
                setState(() => _type = v);
              },
            ),
            const SizedBox(height: 12),
            DropdownButtonFormField<String>(
              initialValue: _currency,
              decoration: InputDecoration(labelText: tr(context, en: 'Currency', zh: '币种')),
              items: _currencies
                  .map((e) => DropdownMenuItem<String>(value: e, child: Text(e)))
                  .toList(growable: false),
              onChanged: (v) {
                if (v == null) return;
                setState(() => _currency = v);
              },
            ),
          ],
        ),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: Text(tr(context, en: 'Cancel', zh: '取消'))),
        FilledButton(
          onPressed: () {
            final name = _nameCtrl.text.trim();
            if (name.isEmpty) return;
            Navigator.pop(
              context,
              _AccountFormResult(name: name, type: _type, currency: _currency),
            );
          },
          child: Text(tr(context, en: 'Save', zh: '保存')),
        ),
      ],
    );
  }
}

class _AccountFormResult {
  final String name;
  final String type;
  final String currency;

  const _AccountFormResult({
    required this.name,
    required this.type,
    required this.currency,
  });
}
