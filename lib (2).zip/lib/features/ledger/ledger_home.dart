import 'dart:async';

import 'package:flutter/material.dart';
import 'package:drift/drift.dart' as d;
import 'package:shared_preferences/shared_preferences.dart';

import '../../app/currency.dart';
import '../../app/settings.dart';
import '../../data/db/app_database.dart';
import '../../l10n/tr.dart';
import '../../l10n/category_i18n.dart';

import 'add_transaction_page.dart';
import 'models.dart';

import '../reports/history_page.dart';
import '../settings/settings_page.dart';

import 'recurring_transaction_service.dart';
import 'widgets/balance_card.dart';
import 'widgets/category_manage_page.dart';
import 'ledger_list_entries.dart';
import 'widgets/monthly_stats_page.dart';
import 'widgets/ledger_tx_list_area.dart';
import 'widgets/ledger_quick_actions.dart';
import 'widgets/ledger_search_panel.dart';
import 'widgets/account_manage_page.dart';
import 'widgets/recurring_transactions_page.dart';

// New small widgets (split out from this file)
import 'widgets/ledger_drawer_shell.dart';
import 'widgets/ledger_side_menu.dart';

class LedgerHome extends StatefulWidget {
  final AppDatabase db;
  final VoidCallback onToggleLocale;
  final VoidCallback onToggleTheme;
  final bool isDarkMode;

  const LedgerHome({
    super.key,
    required this.db,
    required this.onToggleLocale,
    required this.onToggleTheme,
    required this.isDarkMode,
  });

  @override
  State<LedgerHome> createState() => _LedgerHomeState();
}

class _LedgerHomeState extends State<LedgerHome>
    with SingleTickerProviderStateMixin {
  // Screenshot / capture area
  final GlobalKey _txListAreaKey = GlobalKey(debugLabel: 'tx_list_area');

  // Selection mode
  bool _selectMode = false;
  final Set<String> _selectedIds = <String>{};
  List<String> _lastTxIds = const <String>[];

  // Drawer
  late final AnimationController _drawerCtrl;
  static const Duration _drawerDur = Duration(milliseconds: 360);
  static const Curve _drawerCurve = Curves.easeOutCubic;

  // Paged: Home (0) <-> Stats (1)
  late final PageController _pageCtrl;
  Timer? _recurringTimer;
  String _qaSlot3 = 'stats';
  String _qaSlot4 = 'history';
  bool _showSearch = false;
  LedgerFilterState _filter = const LedgerFilterState();
  int? _currentAccountId;
  String _currentAccountCurrency = 'USD';
  static const String _kCurrentAccountPref = 'ledger_current_account_id';

  void _openStats() => _pageCtrl.animateToPage(
    1,
    duration: const Duration(milliseconds: 320),
    curve: Curves.easeOutCubic,
  );
  void _openHome() => _pageCtrl.animateToPage(
    0,
    duration: const Duration(milliseconds: 320),
    curve: Curves.easeOutCubic,
  );

  void _refreshHome() {
    if (!mounted) return;
    setState(() {});
  }

  void _openDrawer() =>
      _drawerCtrl.animateTo(1.0, duration: _drawerDur, curve: _drawerCurve);
  void _closeDrawer() =>
      _drawerCtrl.animateTo(0.0, duration: _drawerDur, curve: _drawerCurve);

  @override
  void initState() {
    super.initState();
    _drawerCtrl = AnimationController(vsync: this, duration: _drawerDur);
    _pageCtrl = PageController(initialPage: 0);
    _loadQuickActions();
    _initCurrentAccount();
    unawaited(_applyRecurringForAllAccounts());
    _recurringTimer = Timer.periodic(const Duration(minutes: 1), (_) {
      unawaited(_applyRecurringForAllAccounts());
    });
  }

  @override
  void dispose() {
    _recurringTimer?.cancel();
    _drawerCtrl.dispose();
    _pageCtrl.dispose();
    super.dispose();
  }

  String _fmtDay(DateTime dt) {
    String two(int n) => n.toString().padLeft(2, '0');
    return '${dt.year}-${two(dt.month)}-${two(dt.day)}';
  }

  String _fmtTime(DateTime dt) {
    String two(int n) => n.toString().padLeft(2, '0');
    return '${two(dt.hour)}:${two(dt.minute)}';
  }

  Future<int> _ensureDefaultAccount() async {
    final existing =
        await (widget.db.select(widget.db.accounts)
              ..where((a) => a.isActive.equals(true))
              ..orderBy([(a) => d.OrderingTerm(expression: a.id)]))
            .get();
    if (existing.isNotEmpty) {
      return existing.first.id;
    }
    final id = await widget.db
        .into(widget.db.accounts)
        .insert(
          AccountsCompanion.insert(
            name: 'Default',
            type: d.Value('cash'),
            currency: d.Value('USD'),
          ),
        );
    return id;
  }

  Future<void> _initCurrentAccount() async {
    final prefs = await SharedPreferences.getInstance();
    final fallback = await _ensureDefaultAccount();
    final prefId = prefs.getInt(_kCurrentAccountPref);

    int selected = fallback;
    if (prefId != null) {
      final hit =
          await (widget.db.select(widget.db.accounts)
                ..where((a) => a.id.equals(prefId) & a.isActive.equals(true)))
              .getSingleOrNull();
      if (hit != null) selected = hit.id;
    }

    await prefs.setInt(_kCurrentAccountPref, selected);
    final current = await (widget.db.select(
      widget.db.accounts,
    )..where((a) => a.id.equals(selected))).getSingleOrNull();
    if (!mounted) return;
    setState(() {
      _currentAccountId = selected;
      _currentAccountCurrency = (current?.currency ?? 'USD').toUpperCase();
    });
  }

  Future<void> _setCurrentAccount(int accountId) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt(_kCurrentAccountPref, accountId);
    final current = await (widget.db.select(
      widget.db.accounts,
    )..where((a) => a.id.equals(accountId))).getSingleOrNull();
    if (!mounted) return;
    setState(() {
      _currentAccountId = accountId;
      _currentAccountCurrency = (current?.currency ?? 'USD').toUpperCase();
      _filter = const LedgerFilterState();
    });
    await _applyRecurringForAccount(accountId);
    _refreshHome();
  }

  Future<void> _applyRecurringForAllAccounts() async {
    final inserted = await RecurringTransactionService.applyDueForAllAccounts(
      widget.db,
    );
    if (inserted > 0 && mounted) {
      _refreshHome();
    }
  }

  Future<void> _applyRecurringForAccount(int accountId) async {
    final account = await (widget.db.select(
      widget.db.accounts,
    )..where((a) => a.id.equals(accountId))).getSingleOrNull();
    if (account == null) return;
    final inserted = await RecurringTransactionService.applyDueForAccount(
      widget.db,
      accountId: accountId,
      accountCurrency: account.currency.toUpperCase(),
    );
    if (inserted > 0 && mounted) {
      _refreshHome();
    }
  }

  Future<void> _switchAccountFromSheet() async {
    final accounts =
        await (widget.db.select(widget.db.accounts)
              ..where((a) => a.isActive.equals(true))
              ..orderBy([
                (a) => d.OrderingTerm(expression: a.sortOrder),
                (a) => d.OrderingTerm(expression: a.id),
              ]))
            .get();
    if (!mounted || accounts.isEmpty) return;

    final picked = await showModalBottomSheet<int>(
      context: context,
      backgroundColor: Colors.transparent,
      barrierColor: Colors.black54,
      showDragHandle: true,
      builder: (_) {
        return SafeArea(
          child: Container(
            margin: const EdgeInsets.fromLTRB(10, 0, 10, 10),
            decoration: BoxDecoration(
              color: Theme.of(context).colorScheme.surface,
              borderRadius: BorderRadius.circular(20),
            ),
            child: ListView.separated(
              shrinkWrap: true,
              itemCount: accounts.length,
              separatorBuilder: (_, __) => const Divider(height: 1),
              itemBuilder: (_, i) {
                final a = accounts[i];
                final selected = a.id == _currentAccountId;
                return ListTile(
                  title: Text(a.name),
                  subtitle: Text(
                    '${a.type.toUpperCase()}  |  ${a.currency.toUpperCase()}',
                  ),
                  tileColor: selected
                      ? Theme.of(
                          context,
                        ).colorScheme.primaryContainer.withValues(alpha: 0.35)
                      : null,
                  trailing: selected ? const Icon(Icons.check_rounded) : null,
                  onTap: () => Navigator.pop(context, a.id),
                );
              },
            ),
          ),
        );
      },
    );
    if (picked == null || picked == _currentAccountId) return;
    await _setCurrentAccount(picked);
  }

  List<TxViewRow> _applyFilters(List<TxViewRow> input) {
    String norm(String s) => s.toLowerCase().trim();
    String two(int n) => n.toString().padLeft(2, '0');
    String fmtDt(DateTime dt) =>
        '${dt.year}-${two(dt.month)}-${two(dt.day)} ${two(dt.hour)}:${two(dt.minute)}';

    final keyword = norm(_filter.keyword);
    final range = _filter.range;
    final categoryId = _filter.categoryId;
    final tokens = keyword
        .split(RegExp(r'\s+'))
        .where((e) => e.isNotEmpty)
        .toList(growable: false);

    return input
        .where((row) {
          if (categoryId != null && row.tx.categoryId != categoryId) {
            return false;
          }

          if (range != null) {
            final start = DateTime(
              range.start.year,
              range.start.month,
              range.start.day,
            );
            final endExclusive = DateTime(
              range.end.year,
              range.end.month,
              range.end.day,
            ).add(const Duration(days: 1));
            final t = row.tx.occurredAt;
            if (t.isBefore(start) || !t.isBefore(endExclusive)) {
              return false;
            }
          }

          if (tokens.isNotEmpty) {
            final categoryNameRaw = row.category?.name ?? '';
            final categoryNameI18n = categoryLabel(context, categoryNameRaw);
            final amount = (row.tx.amountCents / 100.0);
            final fields = <String>[
              row.tx.id,
              row.tx.source,
              row.tx.sourceId ?? '',
              row.tx.direction,
              row.tx.currency,
              row.tx.merchant ?? '',
              row.tx.memo ?? '',
              categoryNameRaw,
              categoryNameI18n,
              amount.toStringAsFixed(2),
              amount.toStringAsFixed(0),
              fmtDt(row.tx.occurredAt),
              '${row.tx.occurredAt.year}-${two(row.tx.occurredAt.month)}-${two(row.tx.occurredAt.day)}',
              row.tx.direction == 'income' ? 'income 收入' : 'expense 支出',
            ].map(norm).toList(growable: false);

            final hitAllTokens = tokens.every((token) {
              return fields.any((f) => f.contains(token));
            });
            if (!hitAllTokens) return false;
          }

          return true;
        })
        .toList(growable: false);
  }

  Future<void> _loadQuickActions() async {
    const kQaSlot3 = 'qa_slot3';
    const kQaSlot4 = 'qa_slot4';
    try {
      final p = await SharedPreferences.getInstance();
      final s3 = p.getString(kQaSlot3);
      final s4 = p.getString(kQaSlot4);
      _qaSlot3 = (s3 == null || s3.isEmpty) ? 'stats' : s3;
      _qaSlot4 = (s4 == null || s4.isEmpty) ? 'history' : s4;
      if (_qaSlot3 == _qaSlot4) {
        _qaSlot4 = _qaSlot3 == 'stats' ? 'history' : 'stats';
      }
      if (mounted) setState(() {});
    } catch (_) {
      // keep defaults
    }
  }

  _QaItem _resolveQa(BuildContext context, String key) {
    switch (key) {
      case 'switchAccount':
        return _QaItem(
          icon: Icons.swap_horiz_rounded,
          tooltip: tr(context, en: 'Switch Account', zh: '切换账户'),
          onTap: () async {
            await _switchAccountFromSheet();
          },
        );
      case 'manageAccounts':
        return _QaItem(
          icon: Icons.account_balance_wallet_rounded,
          tooltip: tr(context, en: 'Manage Accounts', zh: '账户管理'),
          onTap: () async {
            await Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => AccountManagePage(db: widget.db),
              ),
            );
            await _initCurrentAccount();
          },
        );
      case 'recurring':
        return _QaItem(
          icon: Icons.repeat_rounded,
          tooltip: tr(context, en: 'Recurring', zh: '周期交易'),
          onTap: () async {
            if (_currentAccountId == null) return;
            await Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => RecurringTransactionsPage(
                  db: widget.db,
                  accountId: _currentAccountId!,
                  accountCurrency: _currentAccountCurrency,
                ),
              ),
            );
            await _applyRecurringForAccount(_currentAccountId!);
            _refreshHome();
          },
        );
      case 'history':
        return _QaItem(
          icon: Icons.history_rounded,
          tooltip: tr(context, en: 'History', zh: '历史'),
          onTap: () async {
            if (_currentAccountId == null) return;
            await Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => HistoryPage(
                  db: widget.db,
                  accountId: _currentAccountId!,
                  accountCurrency: _currentAccountCurrency,
                ),
              ),
            );
            _refreshHome();
          },
        );
      case 'categories':
        return _QaItem(
          icon: Icons.category_rounded,
          tooltip: tr(context, en: 'Categories', zh: '分类'),
          onTap: () async {
            await Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => CategoryManagePage(db: widget.db),
              ),
            );
            _refreshHome();
          },
        );
      case 'settings':
        return _QaItem(
          icon: Icons.settings_rounded,
          tooltip: tr(context, en: 'Settings', zh: '设置'),
          onTap: () async {
            await Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => SettingsPage(
                  db: widget.db,
                  accountId: _currentAccountId!,
                  onToggleLocale: widget.onToggleLocale,
                ),
              ),
            );
            await _loadQuickActions();
            _refreshHome();
          },
        );
      case 'stats':
      default:
        return _QaItem(
          icon: Icons.bar_chart_rounded,
          tooltip: tr(context, en: 'Stats', zh: '统计'),
          onTap: _openStats,
        );
    }
  }

  @override
  Widget build(BuildContext context) {
    final db = widget.db;
    final onToggleLocale = widget.onToggleLocale;
    final currentAccountId = _currentAccountId;

    final query =
        (db.select(db.transactions)
              ..where((t) => t.accountId.equals(currentAccountId ?? -1))
              ..orderBy([
                (t) => d.OrderingTerm(
                  expression: t.occurredAt,
                  mode: d.OrderingMode.desc,
                ),
              ]))
            .join([
              d.leftOuterJoin(
                db.categories,
                db.categories.id.equalsExp(db.transactions.categoryId),
              ),
            ]);

    final stream = query.watch().map((rows) {
      return rows.map((r) {
        final tx = r.readTable(db.transactions);
        final cat = r.readTableOrNull(db.categories);
        return TxViewRow(tx: tx, category: cat);
      }).toList();
    });

    if (currentAccountId == null) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    return WillPopScope(
      onWillPop: () async {
        // If stats page is visible, go back to home page first.
        final page = _pageCtrl.hasClients ? (_pageCtrl.page ?? 0.0) : 0.0;
        if (page > 0.5) {
          _openHome();
          return false;
        }
        if (_drawerCtrl.value > 0) {
          _closeDrawer();
          return false;
        }
        return true;
      },
      child: LayoutBuilder(
        builder: (context, constraints) {
          final drawerWidth = (constraints.maxWidth * 0.78).clamp(260.0, 360.0);

          Widget buildStatsScaffold() {
            return MonthlyStatsPage(
              db: db,
              accountId: currentAccountId,
              accountCurrency: _currentAccountCurrency,
              onBack: _openHome,
            );
          }

          Widget buildScaffold() {
            return Scaffold(
              backgroundColor: Theme.of(
                context,
              ).colorScheme.surfaceContainerHighest,
              appBar: AppBar(
                leading: _selectMode
                    ? IconButton(
                        tooltip: tr(context, en: 'Cancel', zh: '取消'),
                        icon: const Icon(Icons.close),
                        onPressed: () {
                          setState(() {
                            _selectedIds.clear();
                            _selectMode = false;
                          });
                        },
                      )
                    : IconButton(
                        tooltip: tr(context, en: 'Menu', zh: '菜单'),
                        icon: const Icon(Icons.menu_rounded),
                        onPressed: _openDrawer,
                      ),
                title: Text(
                  _selectMode
                      ? tr(
                          context,
                          en: 'Selected ${_selectedIds.length}',
                          zh: '已选 ${_selectedIds.length}',
                        )
                      : tr(context, en: 'Ledger', zh: '记账'),
                ),
                actions: [
                  if (_selectMode) ...[
                    IconButton(
                      tooltip: tr(context, en: 'Select all', zh: '全选'),
                      icon: const Icon(Icons.select_all),
                      onPressed: () {
                        setState(() {
                          _selectedIds
                            ..clear()
                            ..addAll(_lastTxIds);
                        });
                      },
                    ),
                    IconButton(
                      tooltip: tr(context, en: 'Delete', zh: '删除'),
                      icon: const Icon(Icons.delete_forever),
                      onPressed: _selectedIds.isEmpty
                          ? null
                          : () async {
                              final ok = await showDialog<bool>(
                                context: context,
                                builder: (_) => AlertDialog(
                                  title: Text(
                                    tr(
                                      context,
                                      en: 'Delete selected?',
                                      zh: '删除已选记录？',
                                    ),
                                  ),
                                  content: Text(
                                    tr(
                                      context,
                                      en: 'This cannot be undone.',
                                      zh: '此操作不可撤销。',
                                    ),
                                  ),
                                  actionsPadding: const EdgeInsets.fromLTRB(
                                    16,
                                    0,
                                    16,
                                    12,
                                  ),
                                  actionsAlignment: MainAxisAlignment.end,
                                  actions: [
                                    OutlinedButton(
                                      style: OutlinedButton.styleFrom(
                                        padding: const EdgeInsets.symmetric(
                                          horizontal: 16,
                                          vertical: 12,
                                        ),
                                        shape: RoundedRectangleBorder(
                                          borderRadius: BorderRadius.circular(
                                            12,
                                          ),
                                        ),
                                        side: BorderSide(
                                          color: Theme.of(
                                            context,
                                          ).colorScheme.outline,
                                        ),
                                        backgroundColor: Theme.of(
                                          context,
                                        ).colorScheme.surfaceVariant,
                                      ),
                                      onPressed: () =>
                                          Navigator.pop(context, false),
                                      child: Text(
                                        tr(context, en: 'Cancel', zh: '取消'),
                                      ),
                                    ),
                                    FilledButton(
                                      style: FilledButton.styleFrom(
                                        padding: const EdgeInsets.symmetric(
                                          horizontal: 16,
                                          vertical: 12,
                                        ),
                                        shape: RoundedRectangleBorder(
                                          borderRadius: BorderRadius.circular(
                                            12,
                                          ),
                                        ),
                                        backgroundColor: Theme.of(
                                          context,
                                        ).colorScheme.error,
                                        foregroundColor: Theme.of(
                                          context,
                                        ).colorScheme.onError,
                                      ),
                                      onPressed: () =>
                                          Navigator.pop(context, true),
                                      child: Text(
                                        tr(context, en: 'Delete', zh: '删除'),
                                      ),
                                    ),
                                  ],
                                ),
                              );
                              if (ok != true) return;

                              await (db.delete(db.transactions)..where(
                                    (t) => t.id.isIn(_selectedIds.toList()),
                                  ))
                                  .go();

                              if (!context.mounted) return;
                              setState(() {
                                _selectedIds.clear();
                                _selectMode = false;
                              });
                            },
                    ),
                  ],
                ],
              ),
              body: StreamBuilder<List<TxViewRow>>(
                stream: stream,
                builder: (context, snapshot) {
                  final rawTxs = snapshot.data ?? const <TxViewRow>[];
                  final txs = _applyFilters(rawTxs);
                  _lastTxIds = txs.map((e) => e.tx.id).toList(growable: false);

                  int income = 0;
                  int expense = 0;
                  for (final r in txs) {
                    if (r.tx.direction == 'income') {
                      income += r.tx.amountCents;
                    } else {
                      expense += r.tx.amountCents;
                    }
                  }
                  final balance = (income - expense) / 100.0;

                  final items = <LedgerListEntry>[];
                  String? currentDay;
                  for (final r in txs) {
                    final day = _fmtDay(r.tx.occurredAt);
                    if (day != currentDay) {
                      currentDay = day;
                      items.add(LedgerHeaderEntry(day));
                    }
                    items.add(LedgerTxEntry(r));
                  }

                  Widget txListPanel = Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20),
                    child: RepaintBoundary(
                      key: _txListAreaKey,
                      child: Semantics(
                        label: 'transactions_list_area',
                        child: LedgerTxListArea(
                          txs: txs,
                          items: items,
                          selectMode: _selectMode,
                          selectedIds: _selectedIds,
                          fmtTime: _fmtTime,
                          onEnterSelectWith: (id) {
                            setState(() {
                              _selectMode = true;
                              _selectedIds.add(id);
                            });
                          },
                          onToggleSelected: (id) {
                            setState(() {
                              if (_selectedIds.contains(id)) {
                                _selectedIds.remove(id);
                                if (_selectedIds.isEmpty) _selectMode = false;
                              } else {
                                _selectedIds.add(id);
                              }
                            });
                          },
                          onEditTx: (row) async {
                            if (_selectMode) return;
                            await Navigator.of(context).push(
                              MaterialPageRoute(
                                builder: (_) => AddTransactionPage(
                                  db: db,
                                  accountId: currentAccountId,
                                  accountCurrency: _currentAccountCurrency,
                                  initialTx: row.tx,
                                ),
                              ),
                            );
                          },
                          onDeleteTx: (id) async {
                            if (_selectMode) return;
                            await (db.delete(
                              db.transactions,
                            )..where((t) => t.id.equals(id))).go();
                          },
                        ),
                      ),
                    ),
                  );

                  Widget topPanel = Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20),
                    child: LayoutBuilder(
                      builder: (context, c) {
                        final qa3 = _resolveQa(context, _qaSlot3);
                        final qa4 = _resolveQa(context, _qaSlot4);
                        final actionsWidth = (c.maxWidth * 0.33).clamp(
                          120.0,
                          190.0,
                        );
                        final balanceActionGap = (c.maxWidth * 0.015).clamp(
                          8.0,
                          14.0,
                        );
                        final balanceWidth =
                            c.maxWidth - actionsWidth - balanceActionGap;
                        final panelHeight = balanceWidth * (2 / 3);
                        return Column(
                          children: [
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                SizedBox(
                                  width: balanceWidth,
                                  child: AspectRatio(
                                    aspectRatio: 3 / 2,
                                    child: FutureBuilder<double?>(
                                      future: Settings.getMinBalance(
                                        accountId: currentAccountId,
                                      ),
                                      builder: (context, snap) {
                                        final minB = snap.data;
                                        final isLow =
                                            minB != null && balance < minB;
                                        return BalanceCard(
                                          balance: balance,
                                          currencySymbol: currencySymbol(
                                            _currentAccountCurrency,
                                          ),
                                          isLow: isLow,
                                          accentColor: isLow
                                              ? Colors.red
                                              : Colors.green,
                                          compact: true,
                                        );
                                      },
                                    ),
                                  ),
                                ),
                                SizedBox(width: balanceActionGap),
                                SizedBox(
                                  width: actionsWidth,
                                  height: panelHeight,
                                  child: LedgerQuickActions(
                                    isSearchOpen: _showSearch,
                                    onToggleSearch: () {
                                      setState(() {
                                        _showSearch = !_showSearch;
                                      });
                                    },
                                    onOpenAdd: () async {
                                      await Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                          builder: (_) => AddTransactionPage(
                                            db: db,
                                            accountId: currentAccountId,
                                            accountCurrency:
                                                _currentAccountCurrency,
                                          ),
                                        ),
                                      );
                                      _refreshHome();
                                    },
                                    slot3Icon: qa3.icon,
                                    slot3Tooltip: qa3.tooltip,
                                    onSlot3: qa3.onTap,
                                    slot4Icon: qa4.icon,
                                    slot4Tooltip: qa4.tooltip,
                                    onSlot4: qa4.onTap,
                                  ),
                                ),
                              ],
                            ),
                          ],
                        );
                      },
                    ),
                  );

                  Widget searchPanel = AnimatedSize(
                    duration: const Duration(milliseconds: 220),
                    curve: Curves.easeOutCubic,
                    child: _showSearch
                        ? Padding(
                            padding: const EdgeInsets.fromLTRB(20, 10, 20, 2),
                            child: LedgerSearchPanel(
                              db: db,
                              value: _filter,
                              onChanged: (next) {
                                setState(() {
                                  _filter = next;
                                });
                              },
                            ),
                          )
                        : const SizedBox.shrink(),
                  );

                  final isLandscape =
                      MediaQuery.of(context).orientation ==
                      Orientation.landscape;
                  if (isLandscape) {
                    return Row(
                      children: [
                        SizedBox(
                          width: (constraints.maxWidth * 0.44).clamp(
                            360.0,
                            520.0,
                          ),
                          child: SingleChildScrollView(
                            padding: const EdgeInsets.only(top: 12, bottom: 12),
                            child: Column(children: [topPanel, searchPanel]),
                          ),
                        ),
                        Expanded(
                          child: Column(
                            children: [
                              const SizedBox(height: 12),
                              Expanded(child: txListPanel),
                              const SizedBox(height: 12),
                            ],
                          ),
                        ),
                      ],
                    );
                  }

                  return Column(
                    children: [
                      const SizedBox(height: 12),
                      topPanel,
                      searchPanel,
                      const SizedBox(height: 12),
                      Expanded(child: txListPanel),
                    ],
                  );
                },
              ),
            );
          }

          Widget buildPagedContent() {
            return AnimatedBuilder(
              animation: _pageCtrl,
              builder: (context, _) {
                final page = _pageCtrl.hasClients
                    ? (_pageCtrl.page ?? 0.0)
                    : 0.0;
                final t = page.clamp(0.0, 1.0);

                Widget shell({
                  required Widget child,
                  required double scale,
                  required double radius,
                }) {
                  return Transform.scale(
                    scale: scale,
                    alignment: Alignment.center,
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(radius),
                      child: child,
                    ),
                  );
                }

                final homeScale = 1.0 - (0.03 * t);
                final statsScale = 0.97 + (0.03 * t);
                final radius = 18.0 * (t < 0.5 ? t * 2 : (1 - t) * 2);

                return PageView(
                  controller: _pageCtrl,
                  onPageChanged: (i) {
                    if (i == 0) _refreshHome();
                  },
                  physics: _drawerCtrl.value > 0
                      ? const NeverScrollableScrollPhysics()
                      : const PageScrollPhysics(),
                  children: [
                    shell(
                      child: buildScaffold(),
                      scale: homeScale,
                      radius: radius,
                    ),
                    shell(
                      child: buildStatsScaffold(),
                      scale: statsScale,
                      radius: radius,
                    ),
                  ],
                );
              },
            );
          }

          return LedgerDrawerShell(
            controller: _drawerCtrl,
            drawerWidth: drawerWidth,
            edgeTriggerWidth: 70, // expand drag-to-open area here
            canOpen: !_selectMode,
            duration: _drawerDur,
            curve: _drawerCurve,
            onTapScrim: _closeDrawer,
            drawer: SafeArea(
              child: LedgerSideMenu(
                onSwitchAccount: () async {
                  _closeDrawer();
                  await _switchAccountFromSheet();
                },
                onManageAccounts: () async {
                  _closeDrawer();
                  await Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => AccountManagePage(db: db),
                    ),
                  );
                  await _initCurrentAccount();
                },
                onOpenStats: () {
                  _closeDrawer();
                  _openStats();
                },
                statsPageBuilder: (_) => MonthlyStatsPage(
                  db: widget.db,
                  accountId: currentAccountId,
                  accountCurrency: _currentAccountCurrency,
                ),
                onOpenHistory: () async {
                  _closeDrawer();
                  await Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => HistoryPage(
                        db: widget.db,
                        accountId: currentAccountId,
                        accountCurrency: _currentAccountCurrency,
                      ),
                    ),
                  );
                  _refreshHome();
                },
                onOpenRecurring: () async {
                  _closeDrawer();
                  await Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => RecurringTransactionsPage(
                        db: widget.db,
                        accountId: currentAccountId,
                        accountCurrency: _currentAccountCurrency,
                      ),
                    ),
                  );
                  await _applyRecurringForAccount(currentAccountId);
                  _refreshHome();
                },
                onOpenCategories: () async {
                  _closeDrawer();
                  await Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => CategoryManagePage(db: widget.db),
                    ),
                  );
                  _refreshHome();
                },
                onOpenSettings: () async {
                  _closeDrawer();
                  await Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => SettingsPage(
                        db: widget.db,
                        accountId: currentAccountId,
                        onToggleLocale: onToggleLocale,
                      ),
                    ),
                  );
                  await _loadQuickActions();
                  _refreshHome();
                },
                onToggleTheme: widget.onToggleTheme,
                isDarkMode: widget.isDarkMode,
              ),
            ),
            content: buildPagedContent(),
          );
        },
      ),
    );
  }
}

class _QaItem {
  final IconData icon;
  final String tooltip;
  final VoidCallback onTap;

  const _QaItem({
    required this.icon,
    required this.tooltip,
    required this.onTap,
  });
}
