﻿import 'package:flutter/material.dart';

import '../../app/currency.dart';
import '../../l10n/category_i18n.dart';
import '../../l10n/tr.dart';
import 'models.dart';
import 'widgets/expense_pie.dart';
import 'widgets/income_expense_bar.dart';

class ReportDetailPage extends StatelessWidget {
  final MonthlyReport report;
  final String currencyCode;

  const ReportDetailPage({super.key, required this.report, required this.currencyCode});

  String _two(int n) => n.toString().padLeft(2, '0');
  String _dayKey(DateTime dt) => '${dt.year}-${_two(dt.month)}-${_two(dt.day)}';

  String _catLabel(BuildContext context, String key) {
    if (key == '__other__') return tr(context, en: 'Other', zh: '其他');
    return categoryLabel(context, key);
  }

  @override
  Widget build(BuildContext context) {
    final sym = currencySymbol(currencyCode);
    final net = report.netCents / 100.0;
    final netColor = net >= 0 ? Colors.green : Colors.red;

    final txs = List<MonthlyTx>.from(report.transactions)..sort((a, b) => b.occurredAt.compareTo(a.occurredAt));
    final groups = <String, List<MonthlyTx>>{};
    for (final t in txs) {
      (groups[_dayKey(t.occurredAt)] ??= []).add(t);
    }
    final keys = groups.keys.toList()..sort((a, b) => b.compareTo(a));

    return Scaffold(
      appBar: AppBar(title: Text('${tr(context, en: 'Report', zh: '报表')} ${report.monthKey}')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          IncomeExpenseBar(
            incomeCents: report.incomeCents,
            expenseCents: report.expenseCents,
            expenseLabel: tr(context, en: 'Expense', zh: '支出'),
            incomeLabel: tr(context, en: 'Income', zh: '收入'),
            currencySymbol: sym,
          ),
          const SizedBox(height: 10),
          Center(
            child: Text(
              net >= 0 ? '+$sym${net.toStringAsFixed(2)}' : '-$sym${(-net).toStringAsFixed(2)}',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: netColor),
            ),
          ),
          const SizedBox(height: 14),
          Text(tr(context, en: 'Spending Summary', zh: '支出汇总'), style: const TextStyle(fontWeight: FontWeight.w900)),
          const SizedBox(height: 8),
          ExpensePie(expenseByCategoryCents: report.expenseByCategoryCents, currencySymbol: sym),
          const SizedBox(height: 18),
          Text(tr(context, en: 'Details', zh: '明细'), style: const TextStyle(fontWeight: FontWeight.w900)),
          const SizedBox(height: 8),
          if (txs.isEmpty)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 20),
              child: Text(tr(context, en: 'No transaction details saved in this report yet.', zh: '该报表暂无交易明细。')),
            )
          else
            ...keys.expand((day) {
              final list = groups[day]!;
              return [
                Padding(
                  padding: const EdgeInsets.fromLTRB(2, 12, 2, 6),
                  child: Text(
                    day,
                    style: TextStyle(fontSize: 13, fontWeight: FontWeight.w900, color: Theme.of(context).colorScheme.onSurfaceVariant),
                  ),
                ),
                ...list.map((t) {
                  final isIncome = t.direction == 'income';
                  final amt = t.amountCents / 100.0;
                  final amtStr = (isIncome ? '+$sym' : '-$sym') + amt.abs().toStringAsFixed(2);
                  final amtColor = isIncome ? Colors.green : Colors.red;
                  final timeStr = '${_two(t.occurredAt.hour)}:${_two(t.occurredAt.minute)}';
                  final title = (t.merchant != null && t.merchant!.trim().isNotEmpty) ? t.merchant!.trim() : _catLabel(context, t.categoryName);
                  final subtitle = [
                    timeStr,
                    _catLabel(context, t.categoryName),
                    if (t.memo != null && t.memo!.trim().isNotEmpty) t.memo!.trim(),
                  ].join(' | ');

                  return Card(
                    margin: const EdgeInsets.symmetric(vertical: 4),
                    child: ListTile(
                      leading: Icon(isIncome ? Icons.arrow_downward : Icons.arrow_upward, color: amtColor),
                      title: Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
                      subtitle: Text(subtitle),
                      trailing: Text(amtStr, style: TextStyle(fontWeight: FontWeight.w900, color: amtColor)),
                    ),
                  );
                }),
              ];
            }),
        ],
      ),
    );
  }
}
