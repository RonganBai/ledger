import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../../../data/db/app_database.dart';
import '../../reports/models.dart';
import '../../reports/report_service.dart';
import '../../../l10n/tr.dart';
import 'expense_pie.dart';
import 'income_expense_bar.dart';

/// 统计页面内容（普通页面内容组件，不再是 BottomSheet）。
///
/// 顶部小导航：月 / 周 / 日（日支持 7日 / 3日切换）
/// - 月：本月数据
/// - 周：本周数据（周一 ~ 下周一）
/// - 日：最近 N 天数据（收支占比 + 支出占比）+ 每日余额折线
///
/// 为了不破坏你项目中既有引用，这里仍保留类名 `MonthlyStatsSheet`。
class MonthlyStatsSheet extends StatefulWidget {
  final AppDatabase db;
  const MonthlyStatsSheet({super.key, required this.db});

  @override
  State<MonthlyStatsSheet> createState() => _MonthlyStatsSheetState();
}

class _MonthlyStatsSheetState extends State<MonthlyStatsSheet> with SingleTickerProviderStateMixin {
  late final TabController _tab;
  int _dayRange = 7;

  @override
  void initState() {
    super.initState();
    _tab = TabController(length: 3, vsync: this);
    _tab.addListener(() {
      if (mounted) setState(() {});
    });
  }

  @override
  void dispose() {
    _tab.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Column(
        children: [
        const SizedBox(height: 8),
        _TopStatsTabs(
          controller: _tab,
          showDayToggle: _tab.index == 2,
          dayRange: _dayRange,
          onDayRangeChanged: (v) => setState(() => _dayRange = v),
        ),
        const SizedBox(height: 8),
        const Divider(height: 1),
        Expanded(
          child: TabBarView(
            controller: _tab,
            physics: const BouncingScrollPhysics(),
            children: [
              _MonthStatsView(db: widget.db),
              _WeekStatsView(db: widget.db),
              _DayStatsView(db: widget.db, rangeDays: _dayRange),
            ],
          ),
        ),
        ],
      ),
    );
  }
}

class _TopStatsTabs extends StatelessWidget {
  final TabController controller;
  final bool showDayToggle;
  final int dayRange;
  final ValueChanged<int> onDayRangeChanged;

  const _TopStatsTabs({
    required this.controller,
    required this.showDayToggle,
    required this.dayRange,
    required this.onDayRangeChanged,
  });

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12),
      child: Row(
        children: [
          Expanded(
            child: Container(
              padding: const EdgeInsets.all(4),
              decoration: BoxDecoration(
                color: isDark
                    ? cs.surfaceContainerHighest.withValues(alpha: 160)
                    : cs.surfaceContainerHighest,
                borderRadius: BorderRadius.circular(999),
                border: Border.all(color: cs.outlineVariant),
              ),
              child: TabBar(
                controller: controller,
                dividerColor: Colors.transparent,
                indicator: BoxDecoration(
                  color: cs.surface,
                  borderRadius: BorderRadius.circular(999),
                  boxShadow: const [
                    BoxShadow(blurRadius: 12, spreadRadius: 1, color: Color(0x14000000)),
                  ],
                ),
                labelColor: cs.onSurface,
                unselectedLabelColor: cs.onSurfaceVariant,
                labelStyle: const TextStyle(fontWeight: FontWeight.w900),
                unselectedLabelStyle: const TextStyle(fontWeight: FontWeight.w700),
                tabs: const [
                  Tab(text: '月'),
                  Tab(text: '周'),
                  Tab(text: '日'),
                ],
              ),
            ),
          ),
          const SizedBox(width: 10),
          AnimatedSwitcher(
            duration: const Duration(milliseconds: 160),
            child: showDayToggle
                ? Container(
                    key: const ValueKey('dayToggle'),
                    padding: const EdgeInsets.all(4),
                    decoration: BoxDecoration(
                      color: isDark
                          ? cs.surfaceContainerHighest.withValues(alpha: 160)
                          : cs.surfaceContainerHighest,
                      borderRadius: BorderRadius.circular(999),
                      border: Border.all(color: cs.outlineVariant),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        _PillToggle(
                          text: tr(context, en: '7D', zh: '7日'),
                          selected: dayRange == 7,
                          onTap: () => onDayRangeChanged(7),
                        ),
                        const SizedBox(width: 6),
                        _PillToggle(
                          text: tr(context, en: '3D', zh: '3日'),
                          selected: dayRange == 3,
                          onTap: () => onDayRangeChanged(3),
                        ),
                      ],
                    ),
                  )
                : const SizedBox.shrink(key: ValueKey('noToggle')),
          ),
        ],
      ),
    );
  }
}

class _PillToggle extends StatelessWidget {
  final String text;
  final bool selected;
  final VoidCallback onTap;

  const _PillToggle({
    required this.text,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return InkWell(
      borderRadius: BorderRadius.circular(999),
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 160),
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
        decoration: BoxDecoration(
          color: selected ? cs.surface : Colors.transparent,
          borderRadius: BorderRadius.circular(999),
        ),
        child: Text(
          text,
          style: TextStyle(
            fontWeight: FontWeight.w900,
            color: selected ? cs.onSurface : cs.onSurfaceVariant,
          ),
        ),
      ),
    );
  }
}

class _MonthStatsView extends StatelessWidget {
  final AppDatabase db;
  const _MonthStatsView({required this.db});

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<MonthlyReport>(
      future: ReportService.buildForMonth(db, DateTime.now()),
      builder: (context, snap) {
        if (!snap.hasData) return const Center(child: CircularProgressIndicator());
        final r = snap.data!;
        return ListView(
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
          children: [
            _ReportBody(
              title: tr(context, en: 'This Month (${r.monthKey})', zh: '本月统计（${r.monthKey}）'),
              report: r,
              emptyExpenseHint:
              tr(context, en: 'No expense category data this month', zh: '本月暂无支出分类数据'),
            ),
          ],
        );
      },
    );
  }
}

class _WeekStatsView extends StatelessWidget {
  final AppDatabase db;
  const _WeekStatsView({required this.db});

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<MonthlyReport>(
      future: ReportService.buildForWeek(db, DateTime.now()),
      builder: (context, snap) {
        if (!snap.hasData) return const Center(child: CircularProgressIndicator());
        final r = snap.data!;
        return ListView(
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
          children: [
            _ReportBody(
              title: tr(context, en: 'This Week (${r.monthKey})', zh: '本周统计（${r.monthKey}）'),
              report: r,
              emptyExpenseHint:
              tr(context, en: 'No expense category data this week', zh: '本周暂无支出分类数据'),
            ),
          ],
        );
      },
    );
  }
}

class _DayData {
  final MonthlyReport report;
  final List<int> balancesCents;
  _DayData({required this.report, required this.balancesCents});
}

class _DayStatsView extends StatelessWidget {
  final AppDatabase db;
  final int rangeDays;
  const _DayStatsView({required this.db, required this.rangeDays});

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<_DayData>(
      future: Future.wait([
        ReportService.buildForLastDays(db, rangeDays),
        ReportService.dailyBalanceLastDays(db, rangeDays),
      ]).then((list) {
        return _DayData(
          report: list[0] as MonthlyReport,
          balancesCents: list[1] as List<int>,
        );
      }),
      builder: (context, snap) {
        if (!snap.hasData) return const Center(child: CircularProgressIndicator());

        final data = snap.data!;
        final r = data.report;

        return ListView(
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
          children: [
            Text(
              tr(context, en: 'Daily Balance (${r.monthKey})', zh: '每日余额（${r.monthKey}）'),
              style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w900),
            ),
            const SizedBox(height: 10),
            _BalanceLineChartCard(balancesCents: data.balancesCents, days: rangeDays),
            const SizedBox(height: 16),
            _ReportBody(
              title: tr(context, en: 'Last $rangeDays Days (${r.monthKey})', zh: '最近$rangeDays天（${r.monthKey}）'),
              report: r,
              emptyExpenseHint: tr(
                context,
                en: 'No expense category data in last $rangeDays days',
                zh: '最近$rangeDays天暂无支出分类数据',
              ),
            ),
          ],
        );
      },
    );
  }
}

class _ReportBody extends StatelessWidget {
  final String title;
  final MonthlyReport report;
  final String emptyExpenseHint;

  const _ReportBody({
    required this.title,
    required this.report,
    required this.emptyExpenseHint,
  });

  String _money(double v) => v.toStringAsFixed(2);

  @override
  Widget build(BuildContext context) {
    final r = report;
    final net = r.netCents / 100.0;
    final netColor = net >= 0 ? Colors.green : Colors.red;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Text(
          title,
          textAlign: TextAlign.center,
          style: const TextStyle(fontWeight: FontWeight.w900),
          overflow: TextOverflow.ellipsis,
        ),
        const SizedBox(height: 12),
        IncomeExpenseBar(
          incomeCents: r.incomeCents,
          expenseCents: r.expenseCents,
          expenseLabel: tr(context, en: 'Expense', zh: '支出'),
          incomeLabel: tr(context, en: 'Income', zh: '收入'),
        ),
        const SizedBox(height: 10),
        TweenAnimationBuilder<double>(
          tween: Tween(begin: 0, end: net.abs()),
          duration: const Duration(milliseconds: 1100),
          curve: Curves.easeOutCubic,
          builder: (context, v, _) {
            final text = net >= 0 ? '+\$${_money(v)}' : '-\$${_money(v)}';
            return Text(
              text,
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: netColor),
            );
          },
        ),
        const SizedBox(height: 14),
        if (r.expenseByCategoryCents.isEmpty)
          Padding(
            padding: const EdgeInsets.all(16),
            child: Text(emptyExpenseHint, style: const TextStyle(fontWeight: FontWeight.w700)),
          )
        else
          ExpensePie(expenseByCategoryCents: r.expenseByCategoryCents),
      ],
    );
  }
}

class _BalanceLineChartCard extends StatelessWidget {
  final List<int> balancesCents;
  final int days;
  const _BalanceLineChartCard({required this.balancesCents, required this.days});

  String _money(double v) => v.toStringAsFixed(2);

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;

    final points = balancesCents.map((e) => e / 100.0).toList(growable: false);
    final minV = points.isEmpty ? 0.0 : points.reduce(math.min);
    final maxV = points.isEmpty ? 0.0 : points.reduce(math.max);
    final last = points.isEmpty ? 0.0 : points.last;

    return Card(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: BorderSide(width: 1.2, color: Theme.of(context).dividerColor.withValues(alpha: 110)),
      ),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    tr(context, en: 'Balance Trend', zh: '余额趋势'),
                    style: const TextStyle(fontWeight: FontWeight.w900),
                  ),
                ),
                Text(
                  '\$${_money(last)}',
                  style: TextStyle(fontWeight: FontWeight.w900, color: cs.onSurface),
                ),
              ],
            ),
            const SizedBox(height: 6),
            Text(
              tr(
                context,
                en: 'Last $days day(s)  •  min \$${_money(minV)}  max \$${_money(maxV)}',
                zh: '最近$days天  •  最低\$${_money(minV)}  最高\$${_money(maxV)}',
              ),
              style: TextStyle(color: cs.onSurfaceVariant, fontWeight: FontWeight.w700, fontSize: 12),
            ),
            const SizedBox(height: 12),
            SizedBox(
              height: 170,
              child: CustomPaint(
                painter: _BalanceLinePainter(points: points, axisColor: cs.outlineVariant),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _BalanceLinePainter extends CustomPainter {
  final List<double> points;
  final Color axisColor;

  _BalanceLinePainter({required this.points, required this.axisColor});

  @override
  void paint(Canvas canvas, Size size) {
    final paintAxis = Paint()
      ..color = axisColor
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1;

    final rect = Rect.fromLTWH(0, 0, size.width, size.height);
    canvas.drawRRect(RRect.fromRectAndRadius(rect, const Radius.circular(12)), paintAxis);

    if (points.isEmpty) return;

    final minV = points.reduce(math.min);
    final maxV = points.reduce(math.max);
    final range = (maxV - minV).abs() < 1e-9 ? 1.0 : (maxV - minV);

    const padding = EdgeInsets.fromLTRB(12, 12, 12, 12);
    final w = size.width - padding.left - padding.right;
    final h = size.height - padding.top - padding.bottom;

    Offset mapPoint(int i, double v) {
      final x = padding.left + (points.length == 1 ? 0.0 : (i / (points.length - 1)) * w);
      final t = (v - minV) / range;
      final y = padding.top + (1.0 - t) * h;
      return Offset(x, y);
    }

    // 中线
    final midY = padding.top + h / 2;
    canvas.drawLine(Offset(padding.left, midY), Offset(padding.left + w, midY), paintAxis);

    // 折线（不指定主题色的话默认蓝色即可）
    final linePaint = Paint()
      ..color = Colors.blue
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.2
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round;

    final p0 = mapPoint(0, points[0]);
    final path = Path()..moveTo(p0.dx, p0.dy);
    for (int i = 1; i < points.length; i++) {
      final p = mapPoint(i, points[i]);
      path.lineTo(p.dx, p.dy);
    }
    canvas.drawPath(path, linePaint);

    // 点
    final dotPaint = Paint()..color = Colors.blue;
    for (int i = 0; i < points.length; i++) {
      final p = mapPoint(i, points[i]);
      canvas.drawCircle(p, 3.2, dotPaint);
    }
  }

  @override
  bool shouldRepaint(covariant _BalanceLinePainter oldDelegate) {
    return oldDelegate.points != points || oldDelegate.axisColor != axisColor;
  }
}
