﻿import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'app/app.dart';
import 'data/db/app_database.dart';
import 'features/reports/report_service.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await Supabase.initialize(
    url: 'https://bgktgcnivqvkjhurttm.supabase.co',
    anonKey: 'sb_publishable_Pq1nkxrmB5Ils-eiBImp_A_7PUVBJxv',
  );

  final db = AppDatabase();

  runApp(MyApp(db: db));

  WidgetsBinding.instance.addPostFrameCallback((_) async {
    final client = Supabase.instance.client;
    debugPrint('Supabase inited. url=${client.rest.url}');
    debugPrint('Supabase session=${client.auth.currentSession}');

    try {
      final res = await client.from('accounts').select('id').limit(1);
      debugPrint('Supabase accounts test: $res');
    } catch (e, st) {
      debugPrint('Supabase accounts test failed: $e');
      debugPrint('$st');
    }

    try {
      final accounts = await (db.select(db.accounts)..where((a) => a.isActive.equals(true))).get();
      for (final a in accounts) {
        await ReportService.archiveLastMonthIfNeeded(db, accountId: a.id);
      }
      debugPrint('ReportService.archiveLastMonthIfNeeded done');
    } catch (e, st) {
      debugPrint('ReportService.archiveLastMonthIfNeeded failed: $e');
      debugPrint('$st');
    }
  });
}
